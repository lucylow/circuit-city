<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

## Game architecture
- Keep the imported circuit engine, curriculum, panels, and save hook under `src/game`; the TanStack index renders the workspace to preserve the playable source without replacing app routing.
- Preserve the source browser-local save format and hydrate it after mount; this is an offline single-player game with no source database or accounts.
- Keep source color roles in global CSS as oklch tokens and use the shared Button game variant for imported controls; this preserves the supplied design within the target design system.
- Treat the imported evaluator as a simplified teaching model, not a validated arbitrary-topology solver; advanced mission definitions are curriculum rather than newly implemented simulation support.
- Keep expansion state under `src/game/expansion` with its separate source save key; challenge boards are isolated from campaign saves, reward completion is idempotent, and unsupported solver objectives stay practice-only.
- Use local calendar dates consistently for daily contracts and play streaks; UTC conversion can change the player's day near midnight.
- Validate imported blueprint coordinates, dimensions, component types and sizes before loading them; portable JSON must never produce unbounded boards.
