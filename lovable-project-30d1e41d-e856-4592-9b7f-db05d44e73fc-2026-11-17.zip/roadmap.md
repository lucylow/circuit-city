# Game import
- [x] Inspect uploaded source and inventory capabilities.
- [x] Preserve game design, missions, lessons, and circuit engine.
- [x] Adapt browser save initialization for the app runtime.
- [x] Verify gameplay, campaign navigation, settings, and saved progress.

# Expansion improvements
- [ ] Inspect expansion features and compatibility.
- [ ] Integrate blueprint library, challenges, coaching, and progression while preserving local saves.
- [ ] Test expansion rules and verify playable workflows.
