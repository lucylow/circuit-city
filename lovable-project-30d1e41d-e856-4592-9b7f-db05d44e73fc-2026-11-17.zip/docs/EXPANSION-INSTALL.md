# Circuit Board City — Expansion Pack 2

This is an additive feature pack for the original Lovable project. It adds a progression layer, repeatable daily challenges, scoring, achievements, a coach, inventory utilities, and blueprint helpers without replacing the original circuit board or simulation engine.

## Install

1. Unzip this archive.
2. Copy the contents of `circuit-board-city-lovable/` into the root of your original project, allowing the new `src/expansion` and `docs` files to merge.
3. Do not overwrite the original `src/App.tsx`, `src/types.ts`, `src/engine/circuit.ts`, or `package.json`.
4. Run `npm install` and `npm run build`.
5. Import the modules you want from `src/expansion`.

## Minimal integration

```tsx
import { useExpansion } from './expansion/useExpansion';
import { ExpansionDashboard } from './expansion/components/ExpansionDashboard';
import './expansion/expansion.css';

function ExpansionHUD() {
  const { save, markPlayed, award } = useExpansion();
  React.useEffect(() => { markPlayed(); }, []);
  return <ExpansionDashboard profile={save.profile} />;
}
```

Use `generateDailyChallenge()` to get the date's deterministic challenge. Pass a simulation outcome to `scoreChallenge()` and then call `award(score.total, rewardCoins)`. Call `recordCompletion(challenge.id, score.total)` to persist the completion.

## Blueprint workflow

Use `createBlueprint(name, board, notes)` to validate and snapshot the current board. Append it to `save.blueprints` with `setSave`. `serializeBlueprint` and `parseBlueprint` support portable JSON. `BlueprintLibrary` is a display component; wire its callbacks to your existing board setter and save state.

## Compatibility notes

- React and TypeScript; no new runtime dependencies.
- Browser `localStorage` is used for expansion saves.
- The original save key is not modified.
- The existing simulator remains the authority for circuit status. Expansion scoring consumes outcomes; it does not claim to replace electrical validation.
- Daily challenge selection is deterministic by calendar date, so all players on the same local date receive the same template.
