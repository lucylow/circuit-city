# Lovable handoff

1. Import this ZIP into a new Lovable project or copy the files into its source tree.
2. Confirm the detected framework is Vite + React + TypeScript.
3. Install dependencies with `npm install`.
4. Run `npm run dev` and verify the City Builder screen.
5. Run `npm run build` before publishing.

## Current playable scope
The board supports component placement, two-click orthogonal wire drawing, LED rotation, a quick-connect demo route, a beginner DC diagnostic calculation, campaign navigation, learning cards, settings, local save, and mission reward flow.

## Recommended next implementation prompt for Lovable
"Continue Circuit Board City from the existing code. Do not replace the design system. Implement a proper electrical graph from board coordinates and component terminals; replace the current simplified wire-presence check with continuity and topology validation. Add unit tests for open circuits, reversed LED polarity, series resistance, switch state, and overload. Keep the UI layout and save format backward compatible."

## Important engineering caveat
The starter circuit evaluator is intentionally a first playable teaching model, not a SPICE-equivalent simulator. Its current connectivity model is simplified. Upgrade it before presenting arbitrary user-built circuits as scientifically solved.
