# Expansion Pack 2 — 100-Section Engineering Build Guide
This guide documents extension architecture and gives concrete integration tasks. The original simulator remains authoritative for electrical correctness.

## Section 001 — Expansion architecture
**Implementation focus:** expansion architecture.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 002 — Non-destructive installation
**Implementation focus:** non-destructive installation.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 003 — Type boundaries
**Implementation focus:** type boundaries.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 004 — Profile model
**Implementation focus:** profile model.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 005 — XP progression
**Implementation focus:** xp progression.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 006 — Level thresholds
**Implementation focus:** level thresholds.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 007 — Coin economy
**Implementation focus:** coin economy.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 008 — Daily challenge seed
**Implementation focus:** daily challenge seed.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 009 — Challenge templates
**Implementation focus:** challenge templates.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 010 — Difficulty tuning
**Implementation focus:** difficulty tuning.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 011 — Scoring overview
**Implementation focus:** scoring overview.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 012 — Completion points
**Implementation focus:** completion points.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 013 — Efficiency scoring
**Implementation focus:** efficiency scoring.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 014 — Safety scoring
**Implementation focus:** safety scoring.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 015 — Elegance scoring
**Implementation focus:** elegance scoring.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 016 — Star thresholds
**Implementation focus:** star thresholds.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 017 — Achievement evaluation
**Implementation focus:** achievement evaluation.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 018 — First-light achievement
**Implementation focus:** first-light achievement.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 019 — Hintless achievement
**Implementation focus:** hintless achievement.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 020 — Budget achievement
**Implementation focus:** budget achievement.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 021 — Streak tracking
**Implementation focus:** streak tracking.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 022 — Local date handling
**Implementation focus:** local date handling.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 023 — Inventory model
**Implementation focus:** inventory model.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 024 — Component costs
**Implementation focus:** component costs.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 025 — Inventory consumption
**Implementation focus:** inventory consumption.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 026 — Inventory grants
**Implementation focus:** inventory grants.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 027 — Insufficient stock errors
**Implementation focus:** insufficient stock errors.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 028 — Blueprint schema
**Implementation focus:** blueprint schema.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 029 — Blueprint snapshots
**Implementation focus:** blueprint snapshots.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 030 — Blueprint naming
**Implementation focus:** blueprint naming.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 031 — Blueprint validation
**Implementation focus:** blueprint validation.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 032 — Blueprint serialization
**Implementation focus:** blueprint serialization.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 033 — Blueprint imports
**Implementation focus:** blueprint imports.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 034 — Blueprint exports
**Implementation focus:** blueprint exports.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 035 — Filename sanitization
**Implementation focus:** filename sanitization.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 036 — Blueprint summaries
**Implementation focus:** blueprint summaries.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 037 — Blueprint library UI
**Implementation focus:** blueprint library ui.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 038 — Blueprint deletion
**Implementation focus:** blueprint deletion.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 039 — Blueprint loading
**Implementation focus:** blueprint loading.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 040 — Coach message rules
**Implementation focus:** coach message rules.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 041 — Hint sequencing
**Implementation focus:** hint sequencing.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 042 — Hint penalties
**Implementation focus:** hint penalties.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 043 — Challenge card UI
**Implementation focus:** challenge card ui.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 044 — Expansion dashboard
**Implementation focus:** expansion dashboard.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 045 — XP progress bar
**Implementation focus:** xp progress bar.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 046 — Responsive layout
**Implementation focus:** responsive layout.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 047 — Color contrast
**Implementation focus:** color contrast.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 048 — Keyboard navigation
**Implementation focus:** keyboard navigation.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 049 — Button semantics
**Implementation focus:** button semantics.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 050 — Screen-reader labels
**Implementation focus:** screen-reader labels.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 051 — Expansion save schema
**Implementation focus:** expansion save schema.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 052 — Local storage key
**Implementation focus:** local storage key.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 053 — Save hydration
**Implementation focus:** save hydration.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 054 — Save defaults
**Implementation focus:** save defaults.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 055 — Save corruption recovery
**Implementation focus:** save corruption recovery.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 056 — Save versioning
**Implementation focus:** save versioning.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 057 — Import validation
**Implementation focus:** import validation.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 058 — Export format
**Implementation focus:** export format.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 059 — Storage quota handling
**Implementation focus:** storage quota handling.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 060 — Privacy boundaries
**Implementation focus:** privacy boundaries.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 061 — Event records
**Implementation focus:** event records.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 062 — Event retention
**Implementation focus:** event retention.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 063 — Event summaries
**Implementation focus:** event summaries.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 064 — Session start event
**Implementation focus:** session start event.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 065 — Reward event
**Implementation focus:** reward event.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 066 — Completion event
**Implementation focus:** completion event.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 067 — Avoiding personal data
**Implementation focus:** avoiding personal data.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 068 — Analytics opt-in
**Implementation focus:** analytics opt-in.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 069 — Offline behavior
**Implementation focus:** offline behavior.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 070 — No server requirement
**Implementation focus:** no server requirement.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 071 — Daily challenge repeatability
**Implementation focus:** daily challenge repeatability.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 072 — Challenge rotation
**Implementation focus:** challenge rotation.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 073 — District theming
**Implementation focus:** district theming.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 074 — Allowed component lists
**Implementation focus:** allowed component lists.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 075 — Budget constraints
**Implementation focus:** budget constraints.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 076 — Learning objectives
**Implementation focus:** learning objectives.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 077 — Simulation integration
**Implementation focus:** simulation integration.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 078 — Working-state detection
**Implementation focus:** working-state detection.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 079 — Warning penalties
**Implementation focus:** warning penalties.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 080 — Elapsed-time tracking
**Implementation focus:** elapsed-time tracking.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 081 — Hint-count integration
**Implementation focus:** hint-count integration.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 082 — Board component counts
**Implementation focus:** board component counts.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 083 — Reward calculation
**Implementation focus:** reward calculation.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 084 — Completion persistence
**Implementation focus:** completion persistence.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 085 — Best-score tracking
**Implementation focus:** best-score tracking.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 086 — Duplicate completion handling
**Implementation focus:** duplicate completion handling.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 087 — Profile reset strategy
**Implementation focus:** profile reset strategy.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 088 — Inventory UI extension
**Implementation focus:** inventory ui extension.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 089 — Blueprint workflow
**Implementation focus:** blueprint workflow.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 090 — Challenge routing
**Implementation focus:** challenge routing.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 091 — Testing profile progression
**Implementation focus:** testing profile progression.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 092 — Testing date streaks
**Implementation focus:** testing date streaks.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 093 — Testing scoring edges
**Implementation focus:** testing scoring edges.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 094 — Testing inventory errors
**Implementation focus:** testing inventory errors.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 095 — Testing blueprint parsing
**Implementation focus:** testing blueprint parsing.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 096 — Testing corrupted saves
**Implementation focus:** testing corrupted saves.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 097 — Testing achievements
**Implementation focus:** testing achievements.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 098 — Testing daily seeds
**Implementation focus:** testing daily seeds.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 099 — Testing UI states
**Implementation focus:** testing ui states.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.

## Section 100 — Release checklist
**Implementation focus:** release checklist.

Keep this feature isolated under `src/expansion`. Prefer pure functions for rules, typed inputs and outputs, defensive validation at import boundaries, and small React components for presentation. The original board and circuit engine should remain unchanged unless a deliberate integration step requires otherwise.

**Build task:** wire this capability into the relevant screen, add an accessible loading/empty/error state, and cover the behavior with a focused unit test.
