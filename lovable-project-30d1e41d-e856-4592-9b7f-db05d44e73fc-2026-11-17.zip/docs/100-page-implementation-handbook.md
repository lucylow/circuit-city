# Circuit Board City — 100-page implementation handbook

> These are 100 numbered implementation chapters, not 100 individually typeset printed sheets. The playable code in this ZIP is the starter implementation; chapters identify the next concrete engineering steps and acceptance criteria.

## Page 001 — Product and design foundations

Define the learning loop, target audience, core pillars, player promise, and educational outcomes.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 002 — World architecture

Model the motherboard planet, district boundaries, unlock conditions, day/night presentation, and environmental storytelling.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 003 — Suburbs campaign

Implement the ten beginner missions around complete paths, switches, LEDs, resistors, and troubleshooting.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 004 — Downtown campaign

Introduce series and parallel networks, branch independence, multi-load planning, and fault recovery.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 005 — Industrial campaign

Teach Ohm's law, power, component ratings, fuses, current limits, and simulated protection.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 006 — Smart City campaign

Introduce Boolean logic, transistors, sensors, automated bridges, and control systems.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 007 — Component catalogue

Use a typed catalogue for battery, wire, LED, resistor, switch, diode, capacitor, transistor, gates, motors, sensors, and fuses.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 008 — Board construction

Implement grid snapping, placement validation, rotation, deletion, selection, undo/redo, and touch input.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 009 — Wire drawing

Add orthogonal paths, junction semantics, crossings, wire types, resistance-per-length, and broken segments.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 010 — Circuit graph

Convert board placements into nodes, terminals, edges, branches, and connected components.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 011 — DC solver

Build a nodal-analysis solver for linear resistive networks and a documented sign convention.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 012 — Nonlinear components

Add diode and LED piecewise models, forward voltage, reverse bias, and convergence handling.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 013 — Dynamic simulation

Model capacitors and inductors with time steps, initial conditions, and stability limits.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 014 — Digital logic

Evaluate AND, OR, NOT, NAND, NOR, XOR, timing, and signal propagation.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 015 — Protection and safety

Detect shorts, overloads, invalid topologies, and component rating violations with safe simulated fuse trips.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 016 — Telemetry

Expose node voltage, branch current, resistance, power, energy, and circuit state with units.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 017 — Electron traffic

Map current magnitude to animation density and speed while explaining the metaphor's limits.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 018 — City rendering

Replace the 2D prototype board with Three.js instanced geometry, isometric camera, lighting, and LOD.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 019 — Schematic view

Render standard battery, resistor, LED, switch, junction, ground, and measurement symbols.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 020 — Mission authoring

Represent objectives, allowed components, target states, hints, scoring, and learning outcomes as data.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 021 — Mission evaluation

Separate electrical validity from mission completion and optional efficiency challenges.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 022 — Stars and rewards

Award stars for functioning, safe, and efficient solutions; use cosmetic-only credit sinks.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 023 — Persistence

Version local saves, migrate schemas, debounce writes, export blueprints, and recover corrupt data.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 024 — Sandbox

Offer unlimited placement, configurable board sizes, component inspector, and no mission restrictions.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 025 — Repair Crew

Generate faults such as open wires, reverse LEDs, missing resistors, and open switches.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 026 — Light Show Designer

Create LED patterns, timed sequences, and safe low-voltage visual effects.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 027 — Learning journal

Capture concepts, formula cards, solved examples, and player reflections.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 028 — Characters

Use Sparky for hints, Professor Volt for deeper explanations, Mayor Circuit for missions, and Zippy for current-flow metaphors.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 029 — Dialogue system

Keep dialogue optional, skippable, concise, and triggered by player context.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 030 — Interface layout

Use a central construction canvas, toolbox, mission panel, telemetry, blueprint toggle, and responsive navigation.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 031 — Accessibility

Support keyboard navigation, high contrast, text scaling, captions, reduced motion, and non-color status cues.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 032 — Responsive design

Adapt board controls and panels for desktop, laptop, and tablet browsers.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 033 — Input architecture

Unify pointer, mouse, keyboard, and touch events behind reusable commands.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 034 — Undo and redo

Use immutable board snapshots or command history with bounded memory.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 035 — Component inspector

Expose editable values, terminal orientation, ratings, and educational explanations.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 036 — Simulation controls

Support run, pause, step, reset, speed selection, and deterministic results.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 037 — Fault diagnosis

Explain why a circuit fails, distinguish intentional open switches from accidental breaks, and provide progressive hints.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 038 — Performance

Use instancing, memoized selectors, efficient graph rebuilds, and avoid per-frame React renders.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 039 — Audio design

Add optional placement, power-up, fault, and mission-complete sounds with independent volume settings.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 040 — Visual effects

Use restrained glows, current pulses, building activation, fuse trip effects, and reduced-motion fallbacks.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 041 — Save slots

Support multiple local cities, named projects, duplication, and import/export.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 042 — Blueprint export

Export circuit graph JSON and SVG schematic snapshots.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 043 — Classroom mode

Add teacher-created challenges, privacy-conscious access codes, and progress summaries without collecting unnecessary data.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 044 — Privacy

Avoid public profiles, voice chat, location sharing, or unnecessary student personal information.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 045 — Content localization

Externalize all UI copy and curriculum text for translation.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 046 — Curriculum alignment

Map missions to age-appropriate learning objectives and prerequisite concepts.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 047 — Assessment

Ask prediction questions before simulation and explanation questions after results.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 048 — Testing strategy

Cover solver equations, mission progression, placement, save migrations, accessibility, and browser behavior.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 049 — Unit testing

Verify Ohm's law, series/parallel equivalence, polarity, switch state, power, and fault conditions.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 050 — Integration testing

Test a complete player journey from menu through mission completion and save reload.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 051 — Browser testing

Validate Chrome, Edge, Firefox, Safari, keyboard input, and tablet touch.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 052 — Security

Keep the client-only build free of secrets; validate imported project JSON and bound payload sizes.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 053 — Deployment

Build static assets with Vite and deploy to Lovable hosting or another static host.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 054 — Observability

Use privacy-preserving error diagnostics and opt-in feedback for classroom deployments.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 055 — Content pipeline

Keep levels, lessons, component metadata, and dialogue in typed data files.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 056 — Art pipeline

Create modular low-poly buildings, emissive materials, copper traces, and reusable props.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 057 — Asset licensing

Track provenance and licenses for every imported model, texture, font, and sound.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 058 — Camera controls

Implement pan, zoom, focus selection, and reset-view controls in the 3D edition.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 059 — District progression

Unlock each world after its previous district's capstone mission.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 060 — Mission replay

Allow replay without removing earned stars or credits.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 061 — Challenge variants

Add component-limited, efficiency, repair, and prediction variations.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 062 — Difficulty adaptation

Adjust hints and explanations, not scientific behavior, for different learner levels.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 063 — Power station variants

Introduce batteries, solar panels, and generators with distinct models.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 064 — Wire variants

Model long copper, thin wire current ratings, insulation, and shielded connections.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 065 — Resistor color codes

Teach bands, tolerance, and preferred values in an optional inspection activity.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 066 — LED variants

Add color-dependent forward voltage models and rated current constraints.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 067 — Diode direction

Teach anode/cathode orientation and one-way conduction.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 068 — Capacitor charging

Show charge curves and RC time constants with explicit model assumptions.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 069 — Transistor switching

Introduce NPN and MOSFET switching with safe, bounded educational models.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 070 — Motor loads

Represent electrical-to-mechanical energy conversion and startup current as a simplified model.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 071 — Sensors

Map light, motion, temperature, and distance readings to logic inputs.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 072 — Renewable energy

Use changing solar output and storage as a future campaign system.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 073 — AC foundations

Add a separate AC learning mode and transformer lessons; do not treat transformers as DC resistors.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 074 — City economy

Tie decorative upgrades to credits while never selling educational progress.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 075 — Achievements

Reward meaningful understanding such as fault diagnosis and correct predictions.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 076 — Skill paths

Track construction, power engineering, electronics, and automation mastery.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 077 — Daily challenges

Offer optional short puzzles with no streak penalty.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 078 — Weekly projects

Bundle multiple missions into a larger energy-efficient city project.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 079 — Creative sharing

If added later, require moderation and privacy-safe sharing controls.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 080 — Teacher authoring

Provide a schema-based level editor with validation and preview.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 081 — Teacher reports

Summarize concept mastery rather than exposing unnecessary individual telemetry.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 082 — Localization QA

Check translated labels, number formatting, units, and responsive overflow.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 083 — Color vision

Pair polarity with labels, shapes, and line patterns, not color alone.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 084 — Screen readers

Label controls, status announcements, dialogs, and mission outcomes.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 085 — Motion sensitivity

Respect reduced-motion preference and avoid essential information encoded in animation.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 086 — Audio accessibility

Provide captions or text labels for every gameplay-relevant sound.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 087 — Scientific review

Have an electronics educator review component models, examples, and analogies.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 088 — Safety review

Ensure the game never instructs children to work on mains or unsafe physical circuits.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 089 — Release checklist

Verify build, smoke test, responsive layout, local save, and content completeness.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 090 — Prototype acceptance

Confirm a player can connect a battery, resistor, LED, run a simulation, and explain the result.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 091 — Vertical slice

Polish one neighborhood with 3D assets, animations, a mission, and blueprint mode.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 092 — World One release

Complete ten suburban missions, progression, rewards, and journal.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 093 — Full campaign

Complete Downtown, Industrial Zone, and Smart City mission sets.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 094 — Future expansion

Plan robotics, microcontrollers, communication, PCB design, and supervised hardware integration.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 095 — Long-term vision

Grow the game into a browser-based introduction to electrical engineering and systems thinking.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 096 — Circuit graph persistence

Persist stable node and edge identifiers so saved circuits survive board edits and schema migrations.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 097 — Numerical solver diagnostics

Expose convergence status, singular-matrix explanations, and unsupported-model warnings for advanced circuits.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 098 — Mission authoring validation

Reject malformed level data at development time, including unknown components, invalid rewards, and impossible objectives.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 099 — Browser release verification

Run production builds, smoke tests, keyboard checks, and local-save recovery tests on the supported browser matrix.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---

## Page 100 — Prototype sign-off

Accept the first vertical slice only when a new player can build, simulate, inspect, and explain a working LED circuit.

**Implementation notes**
- Keep the feature modular and testable; separate presentation, game rules, and electrical behavior.
- Store tunable content in typed data rather than scattering values through UI components.
- Add an acceptance test for the player-visible outcome and a regression test for the underlying rule.

**Acceptance criteria**
- The feature works in the browser without requiring a private API key.
- Invalid or incomplete input produces a clear explanation rather than a silent failure.
- The interface remains usable with keyboard and touch input where applicable.

---
