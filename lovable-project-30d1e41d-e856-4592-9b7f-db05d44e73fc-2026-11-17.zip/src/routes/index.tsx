import { createFileRoute } from "@tanstack/react-router";
import GameWorkspace from "@/game/GameWorkspace";

// The home route ships no og:image, so serve-time hosting can inject the
// project's social preview (explicit og:image or latest screenshot).
export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Circuit Board City — Engineering Command Deck" },
      { name: "description", content: "Build copper connections, restore city lights, and explore 40 educational electronics missions in Circuit Board City." },
      { property: "og:title", content: "Circuit Board City — Engineering Command Deck" },
      { property: "og:description", content: "Restore the city one circuit at a time. Play the circuit-building campaign, sandbox, and learning lab." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

// IMPORTANT: Replace this placeholder. See ./README.md for routing conventions.
function Index() {
  return <GameWorkspace />;
}
