import {useEffect,useMemo,useState} from 'react';
import type {CircuitBoard,GameSave} from '../types';
import {createEmptyBoard} from '../engine/circuit';
const KEY='circuit-board-city-save-v1';
const initial:GameSave={completed:[],stars:{},coins:250,rank:'Junior Builder',board:createEmptyBoard(),settings:{sound:true,reducedMotion:false,highContrast:false,showNumbers:true}};
export function useGame(){
 const [save,setSave]=useState<GameSave>(initial);
 const [ready,setReady]=useState(false);
 useEffect(()=>{try{const raw=localStorage.getItem(KEY);if(raw){const saved={...initial,...JSON.parse(raw)};setSave(saved);setBoard(saved.board);}}catch{}setReady(true);},[]);
 const [board,setBoard]=useState<CircuitBoard>(save.board);
 useEffect(()=>{if(!ready)return;try{localStorage.setItem(KEY,JSON.stringify({...save,board}));}catch{}},[save,board,ready]);
 const complete=(id:number,stars:number,reward:number)=>setSave(s=>({...s,completed:s.completed.includes(id)?s.completed:[...s.completed,id],stars:{...s.stars,[id]:Math.max(stars,s.stars[id]??0)},coins:s.coins+reward,rank:id>=40?'Chief Circuit Engineer':id>=31?'Automation Specialist':id>=21?'Power Engineer':id>=11?'Circuit Apprentice':'Junior Builder'}));
 const updateSettings=(patch:Partial<GameSave['settings']>)=>setSave(s=>({...s,settings:{...s.settings,...patch}}));
 const reset=()=>{setSave(initial);setBoard(createEmptyBoard());};
 const totalStars=useMemo(()=>Object.values(save.stars).reduce((a,b)=>a+b,0),[save.stars]);
 return {save,setSave,board,setBoard,complete,updateSettings,reset,totalStars};
}
