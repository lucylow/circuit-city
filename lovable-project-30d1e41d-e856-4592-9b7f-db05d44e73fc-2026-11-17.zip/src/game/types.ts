export type ComponentKind = 'battery'|'wire'|'led'|'resistor'|'switch'|'diode'|'capacitor'|'transistor'|'and'|'or'|'not'|'motor'|'sensor'|'fuse';
export type Point = { x:number; y:number };
export type BoardItem = { id:string; kind:ComponentKind; x:number; y:number; rotation:number; value?:number; enabled?:boolean; polarity?:'forward'|'reverse' };
export type WirePath = { id:string; points:Point[]; color:'copper'|'positive'|'negative'|'insulated'; broken?:boolean };
export type CircuitBoard = { width:number; height:number; items:BoardItem[]; wires:WirePath[] };
export type SimulationResult = { status:'working'|'open'|'fault'|'incomplete'; voltage:number; current:number; resistance:number; power:number; ledOn:boolean; brightness:number; message:string; warnings:string[] };
export type Mission = { id:number; title:string; district:string; objective:string; concept:string; difficulty:'Easy'|'Medium'|'Advanced'; reward:number; required:ComponentKind[]; target:'led'|'two-leds'|'switch'|'parallel'|'repair'|'resistor'|'logic'; lesson:string; };
export type GameSave = { completed:number[]; stars:Record<number,number>; coins:number; rank:string; board: CircuitBoard; settings:{sound:boolean;reducedMotion:boolean;highContrast:boolean;showNumbers:boolean}; };
