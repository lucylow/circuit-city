import { Button } from "@/components/ui/button";
import {useMemo,useState} from 'react';
import {Activity,ArrowLeft,BookOpen,Building2,CircuitBoard,Coins,Command,FlaskConical,Gamepad2,HelpCircle,Lightbulb,Map,Play,RotateCcw,Save,Settings as SettingsIcon, Sparkles, Trophy, Zap} from 'lucide-react';
import type {ComponentKind} from './types';
import {LEVELS} from './data/levels';
import {evaluateCircuit,createEmptyBoard,rotateItem} from './engine/circuit';
import {useGame} from './hooks/useGame';
import Board from './components/Board';
import Toolbox from './components/Toolbox';
import Dashboard from './components/Dashboard';
import MissionPanel from './components/MissionPanel';
import WorldMap from './components/WorldMap';
import LevelGrid from './components/LevelGrid';
import LearnPanel from './components/LearnPanel';
import Settings from './components/Settings';
import Modal from './components/Modal';
import {useExpansion} from './expansion/useExpansion';
import {BlueprintWorkbench} from './expansion/BlueprintWorkbench';
import {ChallengeWorkbench} from './expansion/ChallengeWorkbench';

type Tab='workshop'|'city'|'campaign'|'sandbox'|'learn'|'achievements'|'settings';
export default function GameWorkspace(){
 const game=useGame();
 const ex=useExpansion();
 const [tab,setTab]=useState<Tab>('city');
 const [level,setLevel]=useState(1);
 const [selected,setSelected]=useState<ComponentKind|'wire'|null>('wire');
 const [blueprint,setBlueprint]=useState(false);
 const [modal,setModal]=useState<'help'|'complete'|null>(null);
 const [hint,setHint]=useState(false);
 const mission=LEVELS[level-1] ?? LEVELS[0];
 if(!mission)return null;
 const result=useMemo(()=>evaluateCircuit(game.board),[game.board]);
 const choose=(n:number)=>{setLevel(Math.min(40,Math.max(1,n)));setTab('city');setHint(false);};
 const run=()=>{if(result.status==='working'){setModal('complete');}else setHint(true);};
 const claim=()=>{game.complete(level, result.status==='working'?3:1,mission.reward);setModal(null);};
 const addWirePreset=()=>{game.setBoard({...game.board,wires:[...game.board.wires,{id:crypto.randomUUID(),points:[{x:1,y:5},{x:2,y:5},{x:3,y:5},{x:4,y:5},{x:5,y:5},{x:6,y:5},{x:7,y:5},{x:8,y:5},{x:9,y:5}],color:'copper'}]});};
 const resetBoard=()=>game.setBoard(createEmptyBoard());
 const completeCount=game.save.completed.length;
 return <div className={`app ${game.save.settings.highContrast?'high-contrast':''} ${game.save.settings.reducedMotion?'reduced-motion':''}`}>
  <header className="topbar"><div className="brand"><div className="brand-mark"><CircuitBoard size={23}/></div><div><b>CIRCUIT BOARD <span>CITY</span></b><small>BUILD IT. CONNECT IT. POWER IT.</small></div></div>
   <div className="top-status"><span><i className="live-dot"/> SYSTEM ONLINE</span><span><Zap size={14}/> {game.save.rank}</span><span className="coin-count"><Coins size={15}/> {game.save.coins.toLocaleString()}</span><Button variant="game" size="game" className="icon-button" onClick={()=>setModal('help')} aria-label="Help"><HelpCircle size={18}/></Button></div>
  </header>
  <div className="app-body"><aside className="sidebar"><div className="nav-label">COMMAND DECK</div>
   {([{id:'city',label:'City Builder',icon:Building2},{id:'campaign',label:'Campaign',icon:Map},{id:'sandbox',label:'Sandbox',icon:FlaskConical},{id:'workshop',label:'Workshop',icon:Gamepad2},{id:'learn',label:'Learning Lab',icon:BookOpen},{id:'achievements',label:'Achievements',icon:Trophy},{id:'settings',label:'Settings',icon:SettingsIcon}] as const).map(n=><Button variant="game" size="game" key={n.id} className={`nav-item ${tab===n.id?'active':''}`} onClick={()=>setTab(n.id)}><n.icon size={17}/>{n.label}{n.id==='campaign'&&<small>{completeCount}/40</small>}</Button>)}
   <div className="sidebar-bottom"><div className="engineer-card"><div className="avatar">⚡</div><div><b>{game.save.rank}</b><small>Chief engineer track</small></div></div><div className="sidebar-version">BUILD 1.0.0 · WEB EDITION</div></div>
  </aside>
  <main className="main-content">
   {tab==='city'&&<><div className="page-heading"><div><span className="eyebrow">ENGINEERING OPERATIONS / {mission.district.toUpperCase()}</span><h1>{mission.title}<span className="heading-index"> / MISSION {String(level).padStart(2,'0')}</span></h1><p>Restore the city's power, one connection at a time.</p></div><div className="heading-actions"><Button variant="game" size="game" className="secondary-button" onClick={()=>setBlueprint(v=>!v)}><Command size={15}/>{blueprint?'City view':'X-ray blueprint'}</Button><Button variant="game" size="game" className="secondary-button" onClick={resetBoard}><RotateCcw size={15}/>Reset board</Button></div></div>
    <div className="game-layout"><div className="game-main"><div className="board-card"><Board board={game.board} setBoard={game.setBoard} blueprint={blueprint} selected={selected} onSelectItem={()=>{}}/><div className="board-controls"><Button variant="game" size="game" className="secondary-button small" onClick={addWirePreset}>Quick-connect demo</Button><Button variant="game" size="game" className="secondary-button small" onClick={()=>{const item=game.board.items.find(i=>i.kind==='led');if(item)game.setBoard(rotateItem(game.board,item.id));}}>↻ Rotate LED</Button><Button variant="game" size="game" className="primary-button small" onClick={run}><Play size={14}/>Run simulation</Button></div></div>
     <Toolbox selected={selected} onSelect={setSelected} level={level}/>
    </div><div className="game-side"><MissionPanel mission={mission} completed={game.save.completed.includes(level)} onHint={()=>setHint(v=>!v)} onComplete={run}/>{hint&&<div className="hint-card"><Sparkles size={16}/><div><b>Sparky's hint</b><p>Electricity needs a complete loop. Start at the battery, pass through a load with a suitable resistor, then return to the other battery terminal. Use the copper trace tool to draw a path.</p></div></div>}<Dashboard result={result}/><div className="city-status panel"><span className="eyebrow">DISTRICT STATUS</span><div className="city-status-line"><span>Residential power</span><b className={result.ledOn?'powered':'unpowered'}>{result.ledOn?'ONLINE':'OFFLINE'}</b></div><div className="city-progress"><span style={{width:result.ledOn?'100%':'12%'}}/></div><small>{result.ledOn?'Streetlight network restored.':'Waiting for a stable circuit.'}</small></div></div></div>
   </>}
   {tab==='campaign'&&<><div className="page-heading"><div><span className="eyebrow">MISSION CONTROL</span><h1>Campaign map</h1><p>Four districts. Forty engineering contracts. One city to restore.</p></div></div><WorldMap active={level} completed={game.save.completed} onChoose={choose}/><section className="panel campaign-panel"><div className="panel-heading"><div><span className="eyebrow">MISSION SELECT</span><h3>All operations</h3></div><span className="tiny-count">{completeCount}/40 COMPLETE</span></div><LevelGrid active={level} completed={game.save.completed} stars={game.save.stars} onChoose={choose}/></section></>}
   {tab==='sandbox'&&<><div className="page-heading"><div><span className="eyebrow">CREATIVE OPERATIONS</span><h1>Sandbox City</h1><p>Unlimited imagination. Build circuits without mission restrictions.</p></div><Button variant="game" size="game" className="secondary-button" onClick={resetBoard}><RotateCcw size={15}/>Clear & restart</Button></div><div className="sandbox-banner"><FlaskConical size={22}/><div><b>Free-build environment</b><span>Try components as they unlock. Your sandbox is saved automatically in this browser.</span></div></div><div className="game-layout"><div className="game-main"><div className="board-card"><Board board={game.board} setBoard={game.setBoard} blueprint={blueprint} selected={selected} onSelectItem={()=>{}}/><div className="board-controls"><Button variant="game" size="game" className="secondary-button small" onClick={()=>setBlueprint(v=>!v)}>Toggle schematic</Button><Button variant="game" size="game" className="primary-button small" onClick={run}><Play size={14}/>Run simulation</Button></div></div><Toolbox selected={selected} onSelect={setSelected} level={40}/></div><div className="game-side"><Dashboard result={result}/><div className="panel"><span className="eyebrow">CREATOR'S NOTE</span><p className="muted">Try placing components, drawing pathways, rotating the LED and observing how the diagnostics change.</p></div></div></div></>}
   {tab==='workshop'&&<><div className="page-heading"><div><span className="eyebrow">ENGINEERING WORKSHOP</span><h1>Workshop</h1><p>Daily challenges and your saved circuit blueprints.</p></div></div><section className="panel"><ChallengeWorkbench save={ex.save} onChange={ex.setSave}/></section><section className="panel"><BlueprintWorkbench board={game.board} items={ex.save.blueprints} onChange={b=>ex.setSave(s=>({...s,blueprints:b}))} onLoad={b=>{game.setBoard(b);setTab('sandbox');}}/></section></>}
   {tab==='learn'&&<><div className="page-heading"><div><span className="eyebrow">ENGINEERING KNOWLEDGE BASE</span><h1>Learning lab</h1><p>See it. Build it. Understand it.</p></div></div><LearnPanel/></>}
   {tab==='achievements'&&<><div className="page-heading"><div><span className="eyebrow">CAREER PROGRESSION</span><h1>Engineering record</h1><p>Your city grows as your electrical engineering skills improve.</p></div></div><div className="stats-row"><div className="stat-card"><Trophy/><b>{game.totalStars}</b><small>STARS EARNED</small></div><div className="stat-card"><Activity/><b>{completeCount}</b><small>MISSIONS CLEARED</small></div><div className="stat-card"><Coins/><b>{game.save.coins}</b><small>ENERGY CREDITS</small></div></div><div className="achievement-grid">{[{name:'First Complete Circuit',desc:'Complete your first mission.',done:completeCount>=1,icon:'⚡'},{name:'Suburban Specialist',desc:'Restore all ten suburban missions.',done:completeCount>=10,icon:'⌂'},{name:'Downtown Designer',desc:'Complete the Downtown district.',done:completeCount>=20,icon:'▥'},{name:'Power Engineer',desc:'Complete the Industrial Zone.',done:completeCount>=30,icon:'⚙'},{name:'Automation Architect',desc:'Complete the Smart City campaign.',done:completeCount>=40,icon:'⌘'},{name:'Three-Star Thinker',desc:'Earn 30 mission stars.',done:game.totalStars>=30,icon:'✦'}].map(a=><article className={`achievement-card ${a.done?'unlocked':''}`} key={a.name}><span>{a.icon}</span><div><b>{a.name}</b><small>{a.desc}</small><em>{a.done?'UNLOCKED':'IN PROGRESS'}</em></div></article>)}</div></>}
   {tab==='settings'&&<><div className="page-heading"><div><span className="eyebrow">PREFERENCES</span><h1>Game settings</h1><p>Make your engineering workspace comfortable and accessible.</p></div></div><section className="panel settings-panel"><Settings settings={game.save.settings} onChange={game.updateSettings}/></section><section className="panel reset-panel"><h3>Local save data</h3><p>Your progress is stored in this browser. Resetting removes local campaign progress and the current board.</p><Button variant="game" size="game" className="danger-button" onClick={()=>{if(confirm('Reset all local game progress?'))game.reset();}}>Reset all progress</Button></section></>}
  </main></div>
  {modal==='complete'&&<Modal title="Circuit report" onClose={()=>setModal(null)}><div className="complete-content"><div className="complete-icon">✦</div><h3>Power restored!</h3><p>{result.message}</p><div className="star-row">★★★</div><div className="reward-line"><span>ENGINEERING REWARD</span><b>+{mission.reward} credits</b></div><Button variant="game" size="game" className="primary-button" onClick={claim}>Save result & continue</Button></div></Modal>}
  {modal==='help'&&<Modal title="Field guide" onClose={()=>setModal(null)}><div className="help-content"><p><b>1. Select a tool.</b> Choose copper trace or a component from the depot.</p><p><b>2. Build on the grid.</b> Click two grid cells with the wire tool to draw a copper route. Place components in empty cells.</p><p><b>3. Run the simulation.</b> Review voltage, current, resistance and safety feedback.</p><p><b>4. Switch to X-ray.</b> Compare the city view with an electrical schematic.</p><p className="muted">This is an educational simulation. Do not use the game as instructions for working with real electrical systems.</p></div></Modal>}
  <footer className="footer"><span>© CIRCUIT BOARD CITY</span><span>BUILD A CITY · LEARN ELECTRICITY · THINK LIKE AN ENGINEER</span><span><Save size={12}/> AUTO-SAVE ENABLED</span></footer>
 </div>;
}
