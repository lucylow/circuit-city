import type {SimulationResult} from '../types';
import {fmtCurrent,fmtOhms,fmtPower,fmtVoltage} from '../engine/format';
export default function Dashboard({result}:{result:SimulationResult}){
 return <section className="panel dashboard"><div className="panel-heading"><div><span className="eyebrow">LIVE TELEMETRY</span><h3>Power diagnostics</h3></div><span className={`status-pill ${result.status}`}>{result.status.toUpperCase()}</span></div>
 <div className="metric-grid"><div className="metric"><small>VOLTAGE</small><strong>{fmtVoltage(result.voltage)}</strong><span>Potential difference</span></div><div className="metric"><small>CURRENT</small><strong>{fmtCurrent(result.current)}</strong><span>Charge flow</span></div><div className="metric"><small>RESISTANCE</small><strong>{fmtOhms(result.resistance)}</strong><span>Load resistance</span></div><div className="metric"><small>POWER</small><strong>{fmtPower(result.power)}</strong><span>Resistor dissipation</span></div></div>
 <p className="diagnostic-message">{result.message}</p>{result.warnings.length>0&&<ul className="warning-list">{result.warnings.map(w=><li key={w}>{w}</li>)}</ul>}
 </section>;
}
