import { Button } from "@/components/ui/button";
import {LEVELS} from '../data/levels';
export default function LevelGrid({active,completed,stars,onChoose}:{active:number;completed:number[];stars:Record<number,number>;onChoose:(n:number)=>void}){
 return <div className="level-grid">{LEVELS.map(l=><Button variant="game" size="game" key={l.id} onClick={()=>onChoose(l.id)} className={`level-tile ${active===l.id?'active':''} ${completed.includes(l.id)?'done':''}`}><span>{String(l.id).padStart(2,'0')}</span><b>{l.title}</b><small>{'★'.repeat(stars[l.id]??0)}{'☆'.repeat(3-(stars[l.id]??0))}</small></Button>)}</div>;
}
