import { Button } from "@/components/ui/button";
import type {Mission} from '../types';
export default function MissionPanel({mission,completed,onHint,onComplete}:{mission:Mission;completed:boolean;onHint:()=>void;onComplete:()=>void}){
 return <section className="panel mission-panel"><div className="panel-heading"><div><span className="eyebrow">ACTIVE CONTRACT · {mission.district.toUpperCase()}</span><h3>{mission.title}</h3></div><span className="mission-level">#{String(mission.id).padStart(2,'0')}</span></div>
 <p className="mission-objective">{mission.objective}</p><div className="concept-chip"><span>LEARNING OBJECTIVE</span><b>{mission.concept}</b></div><div className="mission-footer"><Button variant="game" size="game" className="text-button" onClick={onHint}>✦ Request hint</Button><Button variant="game" size="game" className="primary-button small" onClick={onComplete} disabled={completed}>{completed?'Mission completed':'Claim mission result'}</Button></div><div className="reward-line"><span>MISSION REWARD</span><b>⚡ {mission.reward} credits</b></div></section>;
}
