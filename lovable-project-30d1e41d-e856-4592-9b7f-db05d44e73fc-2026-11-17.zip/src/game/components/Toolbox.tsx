import { Button } from "@/components/ui/button";
import {COMPONENTS} from '../data/components';
import type {ComponentKind} from '../types';
type Props={selected:ComponentKind|'wire'|null;onSelect:(kind:ComponentKind|'wire')=>void;level:number;allowed?:ComponentKind[]};
export default function Toolbox({selected,onSelect,level,allowed}:Props){
 const tools=[{kind:'wire' as const,name:'Copper trace',symbol:'〰',city:'Pathway'}];
 return <section className="panel toolbox"><div className="panel-heading"><div><span className="eyebrow">BUILD SYSTEM</span><h3>Component depot</h3></div><span className="tiny-count">TOOLS</span></div>
  <div className="tool-grid">{tools.map(t=><Button variant="game" size="game" key={t.kind} className={`tool ${selected===t.kind?'active':''}`} onClick={()=>onSelect(t.kind)}><span className="tool-symbol">{t.symbol}</span><span><b>{t.name}</b><small>{t.city}</small></span></Button>)}
  {COMPONENTS.filter(c=>c.kind!=='wire'&&(!allowed||allowed.includes(c.kind))).map(c=>{const locked=c.unlock>level;return <Button variant="game" size="game" key={c.kind} disabled={locked} className={`tool ${selected===c.kind?'active':''} ${locked?'locked':''}`} onClick={()=>onSelect(c.kind)} title={locked?`Unlock at mission ${c.unlock}`:c.description}><span className="tool-symbol">{locked?'◇':c.symbol}</span><span><b>{c.name}</b><small>{locked?`Unlock · L${c.unlock}`:c.city}</small></span></Button>})}</div>
 </section>;
}
