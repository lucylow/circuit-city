import { Button } from "@/components/ui/button";
import {useMemo,useState} from 'react';
import type {CircuitBoard,BoardItem,ComponentKind,Point} from '../types';
import {COMPONENTS} from '../data/components';
type Props={board:CircuitBoard;setBoard:(b:CircuitBoard)=>void;blueprint:boolean;selected:ComponentKind|'wire'|null;onSelectItem:(id:string)=>void};
const icon=(kind:ComponentKind)=>COMPONENTS.find(c=>c.kind===kind)?.symbol??'•';
export default function Board({board,setBoard,blueprint,selected,onSelectItem}:Props){
 const [start,setStart]=useState<Point|null>(null);
 const [hover,setHover]=useState<Point|null>(null);
 const cells=useMemo(()=>Array.from({length:board.width*board.height},(_,i)=>({x:i%board.width,y:Math.floor(i/board.width)})),[board.width,board.height]);
 const place=(x:number,y:number)=>{
  const existing=board.items.find(i=>i.x===x&&i.y===y);
  if(existing?.kind==='switch'){onSelectItem(existing.id);return;}
  if(!selected)return;
  if(selected==='wire'){
   if(!start){setStart({x,y});return;}
   const pts:Point[]=[];let cx=start.x,cy=start.y;pts.push({x:cx,y:cy});
   while(cx!==x){cx+=Math.sign(x-cx);pts.push({x:cx,y:cy});}
   while(cy!==y){cy+=Math.sign(y-cy);pts.push({x:cx,y:cy});}
   setBoard({...board,wires:[...board.wires,{id:crypto.randomUUID(),points:pts,color:'copper'}]});setStart(null);return;
  }
  if(existing){onSelectItem(existing.id);return;}
  const def=COMPONENTS.find(c=>c.kind===selected);
  const item:BoardItem={id:crypto.randomUUID(),kind:selected,x,y,rotation:0,value:def?.defaultValue??0,enabled:true,polarity:'forward'};
  setBoard({...board,items:[...board.items,item]});
 };
 const itemAt=(x:number,y:number)=>board.items.find(i=>i.x===x&&i.y===y);
 return <div className={`board-shell ${blueprint?'blueprint':''}`}>
  <div className="board-topline"><span><i className="live-dot"/> MOTHERBOARD · GRID {board.width}×{board.height}</span><span>{blueprint?'SCHEMATIC VIEW':'CITY CONSTRUCTION VIEW'}</span></div>
  <div className="board-grid" style={{gridTemplateColumns:`repeat(${board.width}, minmax(0,1fr))`}}>
   {cells.map(({x,y})=>{const item=itemAt(x,y);return <Button variant="game" size="game" key={`${x}-${y}`} className={`cell ${item?'occupied':''} ${start?.x===x&&start?.y===y?'wire-start':''}`} onClick={()=>place(x,y)} onMouseEnter={()=>setHover({x,y})} aria-label={`Grid ${x+1}, ${y+1}${item?`, ${item.kind}`:''}`}>
    {item?<span className={`piece piece-${item.kind}`} style={{transform:`rotate(${item.rotation}deg)`}}>{blueprint?({battery:'─| |─',led:'▷|',resistor:'─▱─',switch:'─o/ o─'} as Record<string,string>)[item.kind]??icon(item.kind):icon(item.kind)}</span>:null}
    {board.wires.some(w=>w.points.some(p=>p.x===x&&p.y===y))?<span className="wire-mark"/>:null}
   </Button>})}
  </div>
  <div className="board-legend"><span><b className="legend-copper"/> Copper trace</span><span><b className="legend-positive"/> Positive</span><span><b className="legend-negative"/> Return</span><span>{start?`Wire start: ${start.x+1}, ${start.y+1} · choose endpoint`:'Select a tool, then choose a grid cell'}</span></div>
 </div>;
}
