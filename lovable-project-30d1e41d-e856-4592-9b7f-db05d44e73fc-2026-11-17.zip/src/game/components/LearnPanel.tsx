import {LESSONS} from '../data/lessons';
export default function LearnPanel(){return <div className="lesson-list">{LESSONS.map((l,i)=><article className="lesson-card" key={l.title}><div><span className="eyebrow">{l.tag} · 0{i+1}</span><h3>{l.title}</h3></div><p>{l.body}</p><div className="lesson-fact">{l.fact}</div><code>{l.formula}</code></article>)}</div>}
