import { Button } from "@/components/ui/button";
import type {ReactNode} from 'react';
export default function Modal({title,children,onClose}:{title:string;children:ReactNode;onClose:()=>void}){return <div className="modal-backdrop" role="presentation" onMouseDown={e=>{if(e.target===e.currentTarget)onClose()}}><section className="modal" role="dialog" aria-modal="true" aria-label={title}><header><h2>{title}</h2><Button variant="game" size="game" onClick={onClose} aria-label="Close dialog">×</Button></header>{children}</section></div>}
