import type { CircuitBoard } from '../types';
import type { Challenge, ExpansionSave, ScoreBreakdown } from './types';
import { COMPONENT_COST } from './constants';
import { evaluateCircuit } from '../engine/circuit';
import { addProgress } from './profile';
import { evaluateAchievements } from './achievements';
import { logEvent } from './events';

export function boardCost(board: CircuitBoard): number {
  return board.items.reduce((sum, item) => sum + COMPONENT_COST[item.kind], 0) + board.wires.length * COMPONENT_COST.wire;
}

export function evaluateChallenge(challenge: Challenge, board: CircuitBoard): { completed: boolean; reason: string } {
  if (challenge.objective === 'parallel' || challenge.objective === 'logic' || challenge.objective === 'series') {
    return { completed: false, reason: 'Practice only — this objective needs an advanced circuit solver.' };
  }
  if (boardCost(board) > challenge.budget) return { completed: false, reason: 'Component budget exceeded.' };
  if (board.items.some(item => !challenge.allowed.includes(item.kind))) return { completed: false, reason: 'This circuit contains a part outside the allowed toolkit.' };
  const result = evaluateCircuit(board);
  if (result.status !== 'working' || !result.ledOn) return { completed: false, reason: result.message };
  if (challenge.objective === 'limit-current') {
    if (!board.items.some(item => item.kind === 'fuse')) return { completed: false, reason: 'Add the protective fuse.' };
    if (result.current > (challenge.targetCurrentMax ?? 0.03)) return { completed: false, reason: 'Reduce the LED current.' };
  }
  if (challenge.objective === 'switch-control') {
    const sw = board.items.find(item => item.kind === 'switch');
    if (!sw || sw.enabled === false) return { completed: false, reason: 'Add and close the switch.' };
    const openBoard = { ...board, items: board.items.map(item => item.id === sw.id ? { ...item, enabled: false } : item) };
    if (evaluateCircuit(openBoard).ledOn) return { completed: false, reason: 'The switch must turn the light off when open.' };
  }
  return { completed: true, reason: 'Challenge objectives passed in the beginner teaching model.' };
}

export function completeExpansion(save: ExpansionSave, id: string, score: ScoreBreakdown, hintsUsed: number, underBudget: boolean): ExpansionSave {
  if (save.profile.completed.includes(id)) return save;
  const events = logEvent(save.events, 'challenge-complete', { id, score: score.total, stars: score.stars, hintless: hintsUsed === 0, underBudget });
  const profile = { ...addProgress(save.profile, score.total, 50), completed: [...save.profile.completed, id], bestScores: { ...save.profile.bestScores, [id]: score.total } };
  profile.achievements = evaluateAchievements(profile, {
    completed: profile.completed.length,
    hintless: events.filter(e => e.type === 'challenge-complete' && e.detail?.hintless).length,
    underBudget: events.filter(e => e.type === 'challenge-complete' && e.detail?.underBudget).length,
    blueprints: save.blueprints.length,
    threeStars: events.filter(e => e.type === 'challenge-complete' && e.detail?.stars === 3).length,
  });
  return { ...save, profile, events };
}