import { useState } from 'react';
import { Play, Lightbulb, RotateCcw, Trophy, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Board from '../components/Board';
import Dashboard from '../components/Dashboard';
import Toolbox from '../components/Toolbox';
import type { Challenge, ExpansionSave, ScoreBreakdown } from './types';
import type { ComponentKind } from '../types';
import { challengesByDifficulty, generateDailyChallenge } from './challenges';
import { createEmptyBoard, evaluateCircuit } from '../engine/circuit';
import { boardCost, evaluateChallenge, completeExpansion } from './rules';
import { scoreChallenge } from './scoring';
import { coachMessage } from './hints';

export function ChallengeWorkbench({ save, onChange }: { save: ExpansionSave; onChange: (fn: (s: ExpansionSave) => ExpansionSave) => void }) {
  const [daily] = useState(() => generateDailyChallenge());
  const [active, setActive] = useState<Challenge | null>(null);
  const [board, setBoard] = useState(createEmptyBoard);
  const [tool, setTool] = useState<ComponentKind | null>('wire');
  const [hints, setHints] = useState(0);
  const [started, setStarted] = useState(0);
  const [report, setReport] = useState('');
  const [score, setScore] = useState<ScoreBreakdown | null>(null);
  const list = [daily, ...challengesByDifficulty('starter'), ...challengesByDifficulty('standard'), ...challengesByDifficulty('expert')];
  const result = evaluateCircuit(board);
  const start = (challenge: Challenge) => { setActive(challenge); setBoard(createEmptyBoard()); setHints(0); setScore(null); setReport(''); setTool('wire'); setStarted(Date.now()); };
  const run = () => {
    if (!active) return;
    const evaluation = evaluateChallenge(active, board); setReport(evaluation.reason);
    if (!evaluation.completed) { setScore(null); return; }
    const next = scoreChallenge({ completed: true, budgetUsed: boardCost(board), budget: active.budget, warnings: result.warnings.length, hintsUsed: hints, elapsedSeconds: (Date.now()-started)/1000, parSeconds:120, componentCount:board.items.length });
    setScore(next);onChange(s => completeExpansion(s, active.id, next, hints, boardCost(board)<active.budget));
  };
  return <>
    <div className="page-heading"><div><span className="eyebrow">EXPANSION 02 / FIELD OPERATIONS</span><h1>Challenge contracts</h1></div><span className="tiny-count">{save.profile.completed.length} CLEARED</span></div>
    {!active ? <div className="challenge-list">{list.map((c,i) => <article className={`challenge-contract ${i===0?'daily-contract':''}`} key={c.id}><span className="eyebrow">{i===0?'DAILY CONTRACT':c.difficulty.toUpperCase()} / {c.district}</span><h3>{c.title}</h3><p>{c.brief}</p><footer><span>{c.budget} credit budget</span><Button variant="game" size="game" className="secondary-button" onClick={() => start(c)}>{save.profile.completed.includes(c.id)?'Replay': ['parallel','logic'].includes(c.objective)?'Practice':'Start contract'}<Play /></Button></footer>{save.profile.completed.includes(c.id)&&<small className="powered">CLEARED · {save.profile.bestScores[c.id]} XP</small>}</article>)}</div> : <>
      <div className="contract-heading"><div><h2>{active.title}</h2><p>{active.brief}</p></div><Button variant="game" size="game" className="secondary-button" onClick={() => setActive(null)}>All contracts</Button></div>
      <div className="contract-meta"><span className={boardCost(board)>active.budget?'unpowered':'powered'}>BUDGET {boardCost(board)} / {active.budget}</span><span>{hints} HINTS USED</span><span>{save.profile.completed.includes(active.id)?'REWARD CLAIMED':'+50 EXPANSION CREDITS'}</span></div>
      <div className="game-layout"><div className="game-main"><div className="board-card"><Board board={board} setBoard={setBoard} selected={tool} blueprint={false} onSelectItem={id => setBoard(b => ({...b,items:b.items.map(item => item.id===id&&item.kind==='switch'?{...item,enabled:item.enabled===false}:item)}))}/><div className="board-controls"><Button variant="game" size="game" className="secondary-button" onClick={() => start(active)}><RotateCcw />Reset</Button><Button variant="game" size="game" className="primary-button" onClick={run}><Play />Run challenge</Button></div></div><Toolbox selected={tool} onSelect={setTool} level={40} allowed={active.allowed}/></div>
      <div className="game-side"><section className="panel"><div className="panel-heading"><h3>Circuit coach</h3><Lightbulb /></div><p className="diagnostic-message">{coachMessage(result.status,result.warnings)}</p>{hints>0&&<p className="exp-feedback">{active.hints[hints-1]}</p>}<Button variant="game" size="game" className="text-button" disabled={hints>=active.hints.length} onClick={() => setHints(n=>n+1)}>Reveal hint ({hints}/{active.hints.length})</Button></section><Dashboard result={result}/>{report&&<section className="panel" role="status"><p className="diagnostic-message">{report}</p>{score&&<><h2><Trophy />{'★'.repeat(score.stars)}</h2><div className="score-breakdown"><span>Completion <b>{score.completion}</b></span><span>Efficiency <b>{score.efficiency}</b></span><span>Safety <b>{score.safety}</b></span><span>Elegance <b>{score.elegance}</b></span></div><h3 className="powered"><Zap />{score.total} XP</h3></>}</section>}</div></div>
    </>}
  </>;
}