import type { Challenge, Difficulty } from './types';
import type { ComponentKind } from '../types';
import { localDateKey } from './calendar';
const basics:ComponentKind[]=['battery','wire','led','resistor','switch','fuse'];
const pool:Omit<Challenge,'id'|'seed'>[]=[
 {title:'Beacon on the Boulevard',brief:'Build a safe circuit that lights one LED.',district:'Neon Avenue',difficulty:'starter',objective:'light-led',allowed:basics,budget:70,hints:['A battery provides energy.','LEDs need the correct polarity.','A resistor limits current.'],learning:'A closed path allows current to flow.'},
 {title:'Protect the Sign',brief:'Add current limiting and a protective fuse.',district:'Neon Avenue',difficulty:'starter',objective:'limit-current',allowed:basics,budget:90,targetCurrentMax:0.03,hints:['Place a resistor in series.','A fuse is a safety component.'],learning:'Resistance limits current according to Ohm’s law.'},
 {title:'Night Crossing',brief:'Make a switch control the street light.',district:'Switchyard',difficulty:'standard',objective:'switch-control',allowed:[...basics,'diode','capacitor'],budget:110,hints:['The switch must interrupt the conducting path.','Test both switch states.'],learning:'A switch opens and closes an electrical path.'},
 {title:'Twin Towers',brief:'Connect two lamps in parallel.',district:'Highrise Row',difficulty:'standard',objective:'parallel',allowed:[...basics,'capacitor'],budget:130,hints:['Create two branches.','Each branch connects across the same supply.'],learning:'Parallel branches share voltage.'},
 {title:'Logic Gate Plaza',brief:'Explore a simple logic-gate control circuit.',district:'Logic Quarter',difficulty:'expert',objective:'logic',allowed:[...basics,'transistor','and','or','not','sensor'],budget:180,hints:['Identify the required truth-table output.','Use a gate that matches the logic rule.'],learning:'Logic gates transform input states into outputs.'}
];
export function generateDailyChallenge(date=new Date()):Challenge {
 const key=localDateKey(date);
 const seed=[...key].reduce((a,c)=>a+c.charCodeAt(0),17);
 const item=pool[seed%pool.length];
 return {...item,id:`daily-${key}`,seed};
}
export function getChallenge(id:string):Challenge|undefined {
 if(id.startsWith('daily-')) return generateDailyChallenge(new Date(`${id.slice(6)}T12:00:00`));
 return undefined;
}
export function challengesByDifficulty(difficulty:Difficulty):Challenge[] {
 return pool.filter(p=>p.difficulty===difficulty).map((p,i)=>({...p,id:`${difficulty}-${i+1}`,seed:i+1}));
}
