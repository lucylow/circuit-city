import type { PlayerProfile } from './types';
import { XP_PER_LEVEL } from './constants';
import { localDateKey } from './calendar';
export const freshProfile = ():PlayerProfile => ({xp:0,level:1,coins:120,streak:0,lastPlayed:'',unlocked:['district-1'],completed:[],bestScores:{},achievements:[]});
export function addProgress(profile:PlayerProfile, xp:number, coins:number):PlayerProfile {
 const nextXp=Math.max(0,profile.xp+xp);
 return {...profile,xp:nextXp,level:Math.floor(nextXp/XP_PER_LEVEL)+1,coins:Math.max(0,profile.coins+coins)};
}
export function recordPlay(profile:PlayerProfile, date=new Date()):PlayerProfile {
 const today=localDateKey(date);
 if(profile.lastPlayed===today) return profile;
 const yesterday=new Date(date); yesterday.setDate(date.getDate()-1);
 const streak=profile.lastPlayed===localDateKey(yesterday)?profile.streak+1:1;
 return {...profile,streak,lastPlayed:today};
}
export function progressToNextLevel(profile:PlayerProfile):number {
 return (profile.xp%XP_PER_LEVEL)/XP_PER_LEVEL;
}
