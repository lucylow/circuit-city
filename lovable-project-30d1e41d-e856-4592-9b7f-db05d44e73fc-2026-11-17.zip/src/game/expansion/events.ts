import type { EventRecord } from './types';
export function logEvent(events:EventRecord[],type:string,detail:EventRecord['detail']={}):EventRecord[] {
 return [...events.slice(-199),{type,at:Date.now(),detail}];
}
export function summarizeEvents(events:EventRecord[]):Record<string,number> {
 return events.reduce<Record<string,number>>((acc,e)=>{acc[e.type]=(acc[e.type]??0)+1;return acc;},{});
}
