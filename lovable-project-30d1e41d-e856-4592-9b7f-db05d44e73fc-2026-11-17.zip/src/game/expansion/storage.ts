import type { ExpansionSave } from './types';
import { freshProfile } from './profile';
import { STARTER_INVENTORY } from './constants';
const KEY='circuit-board-city-expansion-v1';
export function freshExpansionSave():ExpansionSave {
 return {schema:1,profile:freshProfile(),inventory:STARTER_INVENTORY.map(x=>({...x})),events:[],blueprints:[],preferences:{haptics:false,ambient:false,coach:true}};
}
export function loadExpansionSave():ExpansionSave {
 try {
  const raw=localStorage.getItem(KEY); if(!raw) return freshExpansionSave();
  const parsed=JSON.parse(raw) as Partial<ExpansionSave>;
  if(parsed.schema!==1 || !parsed.profile || !Array.isArray(parsed.inventory)) return freshExpansionSave();
  return {...freshExpansionSave(),...parsed};
 } catch { return freshExpansionSave(); }
}
export function persistExpansionSave(save:ExpansionSave):void {
 try { localStorage.setItem(KEY,JSON.stringify(save)); } catch { /* storage may be disabled or full */ }
}
export function exportSave(save:ExpansionSave):string { return JSON.stringify(save,null,2); }
export function importSave(raw:string):ExpansionSave {
 const value=JSON.parse(raw) as ExpansionSave;
 if(value.schema!==1 || !value.profile || !Array.isArray(value.inventory) || !Array.isArray(value.blueprints)) throw new Error('This is not a supported Circuit Board City expansion save.');
 return {...freshExpansionSave(),...value};
}
