import type { BoardItem, CircuitBoard, ComponentKind, SimulationResult } from '../types';

export type Difficulty = 'starter' | 'standard' | 'expert';
export type Challenge = {
  id: string; title: string; brief: string; district: string; difficulty: Difficulty;
  objective: 'light-led'|'limit-current'|'switch-control'|'series'|'parallel'|'logic'|'repair';
  allowed: ComponentKind[]; budget: number; targetVoltage?: number; targetCurrentMax?: number;
  hints: string[]; learning: string; seed: number;
};
export type ScoreBreakdown = { completion:number; efficiency:number; safety:number; elegance:number; total:number; stars:1|2|3 };
export type Achievement = { id:string; title:string; description:string; icon:string; unlockedAt?:number };
export type PlayerProfile = { xp:number; level:number; coins:number; streak:number; lastPlayed:string; unlocked:string[]; completed:string[]; bestScores:Record<string,number>; achievements:string[] };
export type Blueprint = { schema:1; name:string; createdAt:string; board:CircuitBoard; notes?:string };
export type EventRecord = { type:string; at:number; detail?:Record<string,string|number|boolean> };
export type InventoryItem = { kind:ComponentKind; quantity:number; };
export type ExpansionSave = { schema:1; profile:PlayerProfile; inventory:InventoryItem[]; events:EventRecord[]; blueprints:Blueprint[]; preferences:{haptics:boolean;ambient:boolean;coach:boolean} };
export type Evaluation = { result:SimulationResult; items:BoardItem[]; elapsedSeconds:number; hintsUsed:number; budgetUsed:number };
