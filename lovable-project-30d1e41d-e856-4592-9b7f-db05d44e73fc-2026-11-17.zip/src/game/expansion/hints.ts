import type { Challenge } from './types';
export function getHint(challenge:Challenge,used:number):{text:string;next:number;finished:boolean} {
 if(used>=challenge.hints.length) return {text:'You have seen every hint. Try changing one connection at a time and run the simulation again.',next:used,finished:true};
 return {text:challenge.hints[used],next:used+1,finished:used+1>=challenge.hints.length};
}
export function coachMessage(status:string,warnings:string[]):string {
 if(warnings.length) return `Safety coach: ${warnings[0]}`;
 if(status==='working') return 'Nice work! Your circuit has a complete conducting path.';
 if(status==='open') return 'The path is open. Trace the route from the positive terminal back to the negative terminal.';
 if(status==='fault') return 'Pause and inspect the circuit for a short or unsafe connection.';
 return 'Place the required components, connect them, and run the simulation.';
}
