import type { Blueprint } from './types';
export function downloadText(filename:string,content:string,mime='application/json'):void {
 const blob=new Blob([content],{type:mime}); const url=URL.createObjectURL(blob);
 const anchor=document.createElement('a'); anchor.href=url; anchor.download=filename; anchor.click();
 URL.revokeObjectURL(url);
}
export function blueprintFilename(name:string):string {
 return `${name.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')||'blueprint'}.cbc.json`;
}
export function blueprintSummary(b:Blueprint):string {
 const counts=b.board.items.reduce<Record<string,number>>((acc,item)=>{acc[item.kind]=(acc[item.kind]??0)+1;return acc;},{});
 return Object.entries(counts).map(([kind,n])=>`${n} ${kind}`).join(', ')||'Empty board';
}
