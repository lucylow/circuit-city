import { ACHIEVEMENTS } from './constants';
import type { PlayerProfile } from './types';
export function evaluateAchievements(profile:PlayerProfile,stats:{completed:number;hintless:number;underBudget:number;blueprints:number;threeStars:number}):string[] {
 const earned=new Set(profile.achievements);
 if(stats.completed>0) earned.add('first-light');
 if(stats.hintless>0) earned.add('no-hints');
 if(stats.underBudget>0) earned.add('budget');
 if(profile.streak>=3) earned.add('streak-3');
 if(stats.blueprints>=5) earned.add('blueprint-5');
 if(stats.threeStars>=10) earned.add('perfect-10');
 return [...earned].filter(id=>ACHIEVEMENTS.some(a=>a.id===id));
}
export { ACHIEVEMENTS };
