import type { CircuitBoard } from '../types';
import type { Blueprint } from './types';
import { COMPONENTS } from '../data/components';
export function createBlueprint(name:string,board:CircuitBoard,notes=''):Blueprint {
 const clean=name.trim().slice(0,48);
 if(!clean) throw new Error('Give your blueprint a name first.');
 return {schema:1,name:clean,createdAt:new Date().toISOString(),board:structuredClone(board),notes:notes.slice(0,500)};
}
export function serializeBlueprint(blueprint:Blueprint):string { return JSON.stringify(blueprint,null,2); }
export function parseBlueprint(raw:string):Blueprint {
 if(raw.length>1000000)throw new Error('Blueprint file is too large.');
 const value=JSON.parse(raw) as Blueprint;
 const fail=()=>{throw new Error('Invalid blueprint file.');};
 if(!value || value.schema!==1 || typeof value.name!=='string' || !value.name.trim() || typeof value.createdAt!=='string' || !Number.isFinite(Date.parse(value.createdAt)) || !value.board) return fail();
 const b=value.board;
 if(!Number.isInteger(b.width)||!Number.isInteger(b.height)||b.width<2||b.height<2||b.width>24||b.height>24||!Array.isArray(b.items)||!Array.isArray(b.wires)||b.items.length>576||b.wires.length>576) return fail();
 const point=(p:{x:number;y:number})=>p&&Number.isInteger(p.x)&&Number.isInteger(p.y)&&p.x>=0&&p.y>=0&&p.x<b.width&&p.y<b.height;
 const ids=new Set<string>();const cells=new Set<string>();
 for(const item of b.items){
   const cell=`${item?.x},${item?.y}`;
   if(!item||typeof item.id!=='string'||ids.has(item.id)||cells.has(cell)||!COMPONENTS.some(c=>c.kind===item.kind)||!point(item)||![0,90,180,270].includes(item.rotation)||(item.value!==undefined&&(!Number.isFinite(item.value)||item.value<0))||(item.enabled!==undefined&&typeof item.enabled!=='boolean')||(item.polarity!==undefined&&!['forward','reverse'].includes(item.polarity)))return fail();
   ids.add(item.id);cells.add(cell);
 }
 for(const wire of b.wires)if(!wire||typeof wire.id!=='string'||!Array.isArray(wire.points)||wire.points.length>1152||!wire.points.every(point)||!['copper','positive','negative','insulated'].includes(wire.color)||(wire.broken!==undefined&&typeof wire.broken!=='boolean'))return fail();
 if(value.notes!==undefined&&typeof value.notes!=='string')return fail();
 return {...value,name:value.name.trim().slice(0,48),notes:value.notes?.slice(0,500)};
}
