import type { ComponentKind } from '../types';
import type { InventoryItem } from './types';
export function countOf(items:InventoryItem[],kind:ComponentKind):number { return items.find(i=>i.kind===kind)?.quantity??0; }
export function consume(items:InventoryItem[],kind:ComponentKind,amount=1):InventoryItem[] {
 if(amount<1 || countOf(items,kind)<amount) throw new Error(`Not enough ${kind} parts.`);
 return items.map(i=>i.kind===kind?{...i,quantity:i.quantity-amount}:i);
}
export function grant(items:InventoryItem[],kind:ComponentKind,amount=1):InventoryItem[] {
 if(amount<1) return items;
 return items.some(i=>i.kind===kind)?items.map(i=>i.kind===kind?{...i,quantity:i.quantity+amount}:i):[...items,{kind,quantity:amount}];
}
