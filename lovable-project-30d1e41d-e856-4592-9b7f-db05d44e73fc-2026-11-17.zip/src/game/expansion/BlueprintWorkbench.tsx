import { useRef, useState } from 'react';
import { Download, Upload, Save, Trash2, FolderOpen, CircuitBoard } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { CircuitBoard as Board } from '../types';
import type { Blueprint } from './types';
import { createBlueprint, parseBlueprint, serializeBlueprint } from './blueprints';
import { blueprintFilename, blueprintSummary, downloadText } from './blueprint-codec';

export function BlueprintWorkbench({ board, items, onChange, onLoad }: { board: Board; items: Blueprint[]; onChange: (items: Blueprint[]) => void; onLoad: (b: Board) => void }) {
  const [name, setName] = useState('');
  const [message, setMessage] = useState('');
  const input = useRef<HTMLInputElement>(null);
  const append = (b: Blueprint) => {
    if (items.some(item => item.name.toLowerCase() === b.name.toLowerCase())) throw new Error('That blueprint name already exists. Choose a different name.');
    onChange([...items, b]);
    setMessage(`Saved ${b.name}.`);
  };
  return <>
    <div className="page-heading"><div><span className="eyebrow">DESIGN ARCHIVE</span><h1>Blueprint library</h1></div><Button variant="game" size="game" className="secondary-button" onClick={() => input.current?.click()}><Upload />Import blueprint</Button></div>
    <form className="blueprint-form" onSubmit={e => { e.preventDefault(); try { append(createBlueprint(name, board)); setName(''); } catch (e) { setMessage(e instanceof Error ? e.message : 'Unable to save.'); } }}>
      <label htmlFor="blueprint-name">Current circuit</label><input id="blueprint-name" maxLength={48} value={name} onChange={e => setName(e.target.value)} placeholder="Blueprint name" required />
      <Button variant="game" size="game" className="primary-button" type="submit"><Save />Save blueprint</Button>
    </form>
    <input ref={input} type="file" accept=".json" hidden onChange={async e => { const f=e.target.files?.[0]; if(!f)return; try { if(f.size>1000000)throw new Error('Blueprint file is too large.'); append(parseBlueprint(await f.text())); } catch(e) { setMessage(e instanceof Error?e.message:'Unable to import.'); } if(input.current)input.current.value=''; }} />
    {message && <p className="exp-feedback" role="status">{message}</p>}
    {!items.length && <div className="blueprint-empty"><CircuitBoard size={40}/><h3>No saved designs</h3></div>}
    <div className="blueprint-list">{items.map(b => <article className="blueprint-item" key={b.createdAt+b.name}><CircuitBoard size={28}/><div><h3>{b.name}</h3><p>{blueprintSummary(b)}</p>{b.notes&&<p>{b.notes}</p>}</div><div className="blueprint-actions">
      <Button variant="game" size="game" className="secondary-button" onClick={() => onLoad(structuredClone(b.board))}><FolderOpen />Load</Button>
      <Button variant="game" size="game" className="icon-button" title="Download blueprint" aria-label={`Download ${b.name}`} onClick={() => downloadText(blueprintFilename(b.name), serializeBlueprint(b))}><Download /></Button>
      <Button variant="game" size="game" className="icon-button" title="Delete blueprint" aria-label={`Delete ${b.name}`} onClick={() => { if(confirm(`Delete ${b.name}?`))onChange(items.filter(item => item!==b)); }}><Trash2 /></Button>
    </div></article>)}</div>
  </>;
}