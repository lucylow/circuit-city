import type { ComponentKind } from '../types';
import type { Achievement } from './types';
export const COMPONENT_COST:Record<ComponentKind,number> = {
 battery:30,wire:2,led:12,resistor:8,switch:10,diode:9,capacitor:14,transistor:18,
 and:16,or:16,not:12,motor:25,sensor:20,fuse:7
};
export const XP_PER_LEVEL=250;
export const STARTER_INVENTORY = [
 {kind:'battery' as const,quantity:4},{kind:'wire' as const,quantity:40},
 {kind:'led' as const,quantity:8},{kind:'resistor' as const,quantity:12},
 {kind:'switch' as const,quantity:6},{kind:'diode' as const,quantity:4},
 {kind:'capacitor' as const,quantity:4},{kind:'transistor' as const,quantity:4},
 {kind:'and' as const,quantity:3},{kind:'or' as const,quantity:3},
 {kind:'not' as const,quantity:3},{kind:'motor' as const,quantity:2},
 {kind:'sensor' as const,quantity:2},{kind:'fuse' as const,quantity:5}
];
export const ACHIEVEMENTS:Achievement[] = [
 {id:'first-light',title:'First Light',description:'Complete your first working circuit.',icon:'💡'},
 {id:'no-hints',title:'Independent Thinker',description:'Finish a challenge without hints.',icon:'🧠'},
 {id:'budget',title:'Penny Pincher',description:'Complete a challenge below its component budget.',icon:'🪙'},
 {id:'streak-3',title:'Three-Day Spark',description:'Play on three consecutive days.',icon:'🔥'},
 {id:'blueprint-5',title:'City Architect',description:'Save five blueprints.',icon:'📐'},
 {id:'perfect-10',title:'Precision Engineer',description:'Earn three stars ten times.',icon:'🏆'}
];
