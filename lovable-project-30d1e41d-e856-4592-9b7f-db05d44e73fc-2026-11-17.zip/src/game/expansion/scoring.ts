import type { ScoreBreakdown } from './types';
export function scoreChallenge(input:{completed:boolean;budgetUsed:number;budget:number;warnings:number;hintsUsed:number;elapsedSeconds:number;parSeconds:number;componentCount:number}):ScoreBreakdown {
 if(!input.completed) return {completion:0,efficiency:0,safety:0,elegance:0,total:0,stars:1};
 const completion=400;
 const efficiency=Math.round(250*Math.max(0,1-input.budgetUsed/Math.max(1,input.budget)));
 const safety=Math.max(0,200-input.warnings*50);
 const elegance=Math.max(0,150-input.hintsUsed*35-Math.max(0,input.elapsedSeconds-input.parSeconds)*.5-input.componentCount*2);
 const total=Math.round(completion+efficiency+safety+elegance);
 return {completion,efficiency,safety,elegance,total,stars:total>=850?3:total>=650?2:1};
}
