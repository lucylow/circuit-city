import {useEffect,useState} from 'react';
import type { ExpansionSave } from './types';
import {freshExpansionSave,loadExpansionSave,persistExpansionSave} from './storage';
import {addProgress,recordPlay} from './profile';
import {logEvent} from './events';
export function useExpansion() {
 const [save,setSave]=useState<ExpansionSave>(freshExpansionSave);
 const [ready,setReady]=useState(false);
 useEffect(()=>{const loaded=loadExpansionSave();setSave({...loaded,profile:recordPlay(loaded.profile)});setReady(true);},[]);
 useEffect(()=>{if(ready)persistExpansionSave(save);},[save,ready]);
 const award=(xp:number,coins:number,reason='challenge')=>setSave(s=>({...s,profile:addProgress(s.profile,xp,coins),events:logEvent(s.events,'reward',{xp,coins,reason})}));
 const markPlayed=()=>setSave(s=>({...s,profile:recordPlay(s.profile),events:logEvent(s.events,'session-start')}));
 const recordCompletion=(id:string,score:number)=>setSave(s=>({...s,profile:{...s.profile,completed:s.profile.completed.includes(id)?s.profile.completed:[...s.profile.completed,id],bestScores:{...s.profile.bestScores,[id]:Math.max(score,s.profile.bestScores[id]??0)}},events:logEvent(s.events,'challenge-complete',{id,score})}));
 return {save,setSave,award,markPlayed,recordCompletion,ready};
}
