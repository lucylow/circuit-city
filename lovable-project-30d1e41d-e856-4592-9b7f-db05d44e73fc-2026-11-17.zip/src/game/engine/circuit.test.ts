import {describe,it,expect} from 'vitest';
import {createEmptyBoard,evaluateCircuit} from './circuit';
describe('Circuit Board City starter board',()=>{
 it('starts incomplete until a trace is drawn',()=>expect(evaluateCircuit(createEmptyBoard()).status).toBe('incomplete'));
 it('runs a safe LED circuit after connecting the path',()=>{
  const b=createEmptyBoard();b.wires=[{id:'w',color:'copper',points:[{x:1,y:5},{x:9,y:5}]}];
  const r=evaluateCircuit(b);expect(r.status).toBe('working');expect(r.ledOn).toBe(true);expect(r.current).toBeGreaterThan(0);
 });
});
