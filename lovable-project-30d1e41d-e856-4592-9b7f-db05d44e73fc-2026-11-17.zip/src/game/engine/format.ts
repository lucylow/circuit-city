export const fmtCurrent=(a:number)=>a<0.1?`${(a*1000).toFixed(2)} mA`:`${a.toFixed(3)} A`;
export const fmtVoltage=(v:number)=>`${v.toFixed(1)} V`;
export const fmtOhms=(r:number)=>r>=1000?`${(r/1000).toFixed(2)} kΩ`:`${r.toFixed(0)} Ω`;
export const fmtPower=(w:number)=>w<1?`${(w*1000).toFixed(2)} mW`:`${w.toFixed(3)} W`;
