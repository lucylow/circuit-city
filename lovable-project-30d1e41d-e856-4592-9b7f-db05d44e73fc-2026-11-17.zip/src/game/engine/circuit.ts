import type {BoardItem,CircuitBoard,SimulationResult} from '../types';
export const createEmptyBoard = (width=12,height=12):CircuitBoard => ({width,height,items:[
 {id:'battery-1',kind:'battery',x:1,y:5,rotation:0,value:9},
 {id:'led-1',kind:'led',x:9,y:5,rotation:0,value:2,polarity:'forward'},
 {id:'resistor-1',kind:'resistor',x:6,y:5,rotation:0,value:330}
],wires:[]});
export function evaluateCircuit(board:CircuitBoard):SimulationResult {
 const battery=board.items.find(i=>i.kind==='battery');
 const led=board.items.find(i=>i.kind==='led');
 const resistor=board.items.find(i=>i.kind==='resistor');
 const sw=board.items.find(i=>i.kind==='switch');
 const voltage=battery?.value ?? 9;
 const resistance=Math.max(1,resistor?.value ?? 330);
 const hasPath=board.wires.length>0 && board.wires.some(w=>!w.broken && w.points.length>1);
 const complete=!!battery && !!led && !!resistor && hasPath;
 const warnings:string[]=[];
 if(!battery || !led) warnings.push('Place a battery and an LED to begin.');
 if(!resistor) warnings.push('Add a current-limiting resistor in series with the LED.');
 if(sw && sw.enabled===false) warnings.push('The drawbridge switch is open. Close it to restore the path.');
 if(led?.polarity==='reverse') warnings.push('The LED is reverse-biased. Rotate it to correct the polarity.');
 const open=!!sw && sw.enabled===false || board.wires.some(w=>w.broken);
 const current=complete && !open && led?.polarity!=='reverse' ? Math.max(0,(voltage-(led?.value??2))/resistance) : 0;
 const power=current*current*resistance;
 const status:SimulationResult['status']=!complete?'incomplete':open || led?.polarity==='reverse'?'open':current>0.03?'fault':'working';
 if(current>0.03) warnings.push('Current exceeds this mission’s suggested LED range. Increase the resistance.');
 const ledOn=status==='working' && current>0.001;
 return {status,voltage,current,resistance,power,ledOn,brightness:Math.min(1,current/0.012),message:status==='working'?'Circuit complete — the district is receiving power.':status==='open'?'The electrical path is interrupted. Check the switch, wire and LED direction.':status==='fault'?'The simulated protection system detected excessive current.':'Connect the required components and draw a copper path to run the simulation.',warnings};
}
export function addItem(board:CircuitBoard,item:BoardItem):CircuitBoard {
 return {...board,items:[...board.items,item]};
}
export function removeItem(board:CircuitBoard,id:string):CircuitBoard {
 return {...board,items:board.items.filter(i=>i.id!==id)};
}
export function connectWire(board:CircuitBoard,points:{x:number;y:number}[]):CircuitBoard {
 if(points.length<2)return board;
 return {...board,wires:[...board.wires,{id:crypto.randomUUID(),points,color:'copper'}]};
}
export function moveItem(board:CircuitBoard,id:string,x:number,y:number):CircuitBoard {
 return {...board,items:board.items.map(i=>i.id===id?{...i,x,y}:i)};
}
export function rotateItem(board:CircuitBoard,id:string):CircuitBoard {
 return {...board,items:board.items.map(i=>i.id===id?{...i,rotation:(i.rotation+90)%360}:i)};
}
export function validateBoard(board:CircuitBoard):string[] {
 const errors:string[]=[];
 for(const item of board.items) if(item.x<0||item.y<0||item.x>=board.width||item.y>=board.height) errors.push(`${item.kind} is outside the board.`);
 if(board.items.filter(i=>i.kind==='battery').length>1) errors.push('The beginner DC mode supports one ideal battery.');
 return errors;
}
