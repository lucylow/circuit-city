export const LESSONS = [
 {title:'A complete circuit',tag:'FOUNDATIONS',body:'Current requires a complete conducting path from one battery terminal, through the load, and back to the other terminal.',fact:'An open switch or broken wire interrupts the path.',formula:'I = V / R'},
 {title:'Voltage, current and resistance',tag:'OHM\'S LAW',body:'Voltage is electrical potential difference, current is charge flow per unit time, and resistance opposes current.',fact:'For an ideal resistor, doubling resistance at fixed voltage halves current.',formula:'V = I × R'},
 {title:'Series circuits',tag:'NETWORKS',body:'Components in series share the same current. Their voltage drops add around the loop.',fact:'One open component interrupts the single path.',formula:'Rtotal = R1 + R2 + …'},
 {title:'Parallel circuits',tag:'NETWORKS',body:'Parallel branches share the same voltage across their endpoints. Current divides between branches.',fact:'One failed branch does not necessarily turn off the others.',formula:'1/Rtotal = 1/R1 + 1/R2 + …'},
 {title:'LED polarity',tag:'SEMICONDUCTORS',body:'An LED is a polarized diode. It emits light when forward biased and supplied with an appropriate current.',fact:'A series resistor is commonly used to limit current.',formula:'I ≈ (Vs − Vf) / R'},
 {title:'Electrical power',tag:'ENGINEERING',body:'Power describes the rate of electrical energy transfer. Component ratings matter when choosing parts.',fact:'A resistor that dissipates too much power can overheat.',formula:'P = V × I = I²R'},
 {title:'Logic gates',tag:'AUTOMATION',body:'Digital logic uses Boolean inputs and outputs. Gates combine signals to make decisions.',fact:'An AND gate is true only when every input is true.',formula:'AND: 1 AND 1 = 1'}
];
