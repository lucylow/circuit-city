import type { Mission } from '../types';
export const LEVELS: Mission[] = [
  {
    "id": 1,
    "title": "Bring the Lights Back",
    "district": "The Suburbs",
    "objective": "Connect the 9V power station to one LED and return to the negative terminal.",
    "concept": "Basic closed circuit",
    "difficulty": "Easy",
    "reward": 100,
    "required": [
      "battery",
      "wire",
      "led"
    ],
    "target": "led",
    "lesson": "Basic closed circuit. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 2,
    "title": "The Broken Connection",
    "district": "The Suburbs",
    "objective": "Repair the missing section of copper trace.",
    "concept": "Open circuits",
    "difficulty": "Easy",
    "reward": 110,
    "required": [
      "battery",
      "wire",
      "led"
    ],
    "target": "led",
    "lesson": "Open circuits. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 3,
    "title": "The Drawbridge Switch",
    "district": "The Suburbs",
    "objective": "Use a switch to control the streetlight.",
    "concept": "Switches",
    "difficulty": "Easy",
    "reward": 120,
    "required": [
      "battery",
      "wire",
      "led",
      "switch"
    ],
    "target": "switch",
    "lesson": "Switches. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 4,
    "title": "Double the Neighborhood",
    "district": "The Suburbs",
    "objective": "Connect two lights in one continuous path.",
    "concept": "Series loads",
    "difficulty": "Easy",
    "reward": 130,
    "required": [
      "battery",
      "wire",
      "led"
    ],
    "target": "led",
    "lesson": "Series loads. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 5,
    "title": "The LED Emergency",
    "district": "The Suburbs",
    "objective": "Rotate the LED so its anode faces the positive side.",
    "concept": "LED polarity",
    "difficulty": "Easy",
    "reward": 140,
    "required": [
      "battery",
      "wire",
      "led"
    ],
    "target": "led",
    "lesson": "LED polarity. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 6,
    "title": "The Tollbooth",
    "district": "The Suburbs",
    "objective": "Add a current-limiting resistor in series with the LED.",
    "concept": "Ohm's law",
    "difficulty": "Easy",
    "reward": 150,
    "required": [
      "battery",
      "wire",
      "led",
      "resistor"
    ],
    "target": "led",
    "lesson": "Ohm's law. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 7,
    "title": "Electrical Detectives",
    "district": "The Suburbs",
    "objective": "Inspect the circuit and repair the faulty connection.",
    "concept": "Troubleshooting",
    "difficulty": "Easy",
    "reward": 160,
    "required": [
      "battery",
      "wire",
      "led",
      "resistor"
    ],
    "target": "repair",
    "lesson": "Troubleshooting. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 8,
    "title": "Neighborhood Expansion",
    "district": "The Suburbs",
    "objective": "Power three neighborhood buildings.",
    "concept": "Circuit planning",
    "difficulty": "Easy",
    "reward": 170,
    "required": [
      "battery",
      "wire",
      "led",
      "resistor"
    ],
    "target": "led",
    "lesson": "Circuit planning. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 9,
    "title": "Power Five Houses",
    "district": "The Suburbs",
    "objective": "Explore how independent branches behave in a parallel network.",
    "concept": "Parallel branches",
    "difficulty": "Easy",
    "reward": 180,
    "required": [
      "battery",
      "wire",
      "led",
      "resistor"
    ],
    "target": "parallel",
    "lesson": "Parallel branches. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 10,
    "title": "The Great Suburban Blackout",
    "district": "The Suburbs",
    "objective": "Restore the district and protect every light.",
    "concept": "Combined skills",
    "difficulty": "Easy",
    "reward": 190,
    "required": [
      "battery",
      "wire",
      "led",
      "resistor"
    ],
    "target": "repair",
    "lesson": "Combined skills. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 11,
    "title": "Downtown Highway",
    "district": "Downtown Rush Hour",
    "objective": "Design a reliable electrical system for downtown highway.",
    "concept": "Electrical pathways",
    "difficulty": "Medium",
    "reward": 150,
    "required": [
      "battery",
      "wire",
      "led",
      "switch"
    ],
    "target": "led",
    "lesson": "Electrical pathways. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 12,
    "title": "One Shared Street",
    "district": "Downtown Rush Hour",
    "objective": "Design a reliable electrical system for one shared street.",
    "concept": "Series circuits",
    "difficulty": "Medium",
    "reward": 160,
    "required": [
      "battery",
      "wire",
      "led",
      "switch"
    ],
    "target": "led",
    "lesson": "Series circuits. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 13,
    "title": "A Missing Link",
    "district": "Downtown Rush Hour",
    "objective": "Design a reliable electrical system for a missing link.",
    "concept": "Open series path",
    "difficulty": "Medium",
    "reward": 170,
    "required": [
      "battery",
      "wire",
      "led",
      "switch"
    ],
    "target": "switch",
    "lesson": "Open series path. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 14,
    "title": "Branching Boulevard",
    "district": "Downtown Rush Hour",
    "objective": "Design a reliable electrical system for branching boulevard.",
    "concept": "Parallel circuits",
    "difficulty": "Medium",
    "reward": 180,
    "required": [
      "battery",
      "wire",
      "led",
      "switch"
    ],
    "target": "led",
    "lesson": "Parallel circuits. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 15,
    "title": "Skyscraper Backup",
    "district": "Downtown Rush Hour",
    "objective": "Design a reliable electrical system for skyscraper backup.",
    "concept": "Branch independence",
    "difficulty": "Medium",
    "reward": 190,
    "required": [
      "battery",
      "wire",
      "led",
      "switch"
    ],
    "target": "led",
    "lesson": "Branch independence. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 16,
    "title": "Mall Power Grid",
    "district": "Downtown Rush Hour",
    "objective": "Design a reliable electrical system for mall power grid.",
    "concept": "Multiple loads",
    "difficulty": "Medium",
    "reward": 200,
    "required": [
      "battery",
      "wire",
      "led",
      "resistor",
      "switch"
    ],
    "target": "led",
    "lesson": "Multiple loads. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 17,
    "title": "Load Balancing",
    "district": "Downtown Rush Hour",
    "objective": "Design a reliable electrical system for load balancing.",
    "concept": "Current distribution",
    "difficulty": "Medium",
    "reward": 210,
    "required": [
      "battery",
      "wire",
      "led",
      "resistor",
      "switch"
    ],
    "target": "repair",
    "lesson": "Current distribution. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 18,
    "title": "Downtown Repair Crew",
    "district": "Downtown Rush Hour",
    "objective": "Design a reliable electrical system for downtown repair crew.",
    "concept": "Fault diagnosis",
    "difficulty": "Medium",
    "reward": 220,
    "required": [
      "battery",
      "wire",
      "led",
      "resistor",
      "switch"
    ],
    "target": "led",
    "lesson": "Fault diagnosis. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 19,
    "title": "Independent Towers",
    "district": "Downtown Rush Hour",
    "objective": "Design a reliable electrical system for independent towers.",
    "concept": "Parallel networks",
    "difficulty": "Medium",
    "reward": 230,
    "required": [
      "battery",
      "wire",
      "led",
      "resistor",
      "switch"
    ],
    "target": "parallel",
    "lesson": "Parallel networks. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 20,
    "title": "Rush Hour Blackout",
    "district": "Downtown Rush Hour",
    "objective": "Design a reliable electrical system for rush hour blackout.",
    "concept": "Network redesign",
    "difficulty": "Medium",
    "reward": 240,
    "required": [
      "battery",
      "wire",
      "led",
      "resistor",
      "switch"
    ],
    "target": "repair",
    "lesson": "Network redesign. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 21,
    "title": "Robot Factory",
    "district": "The Industrial Zone",
    "objective": "Design a reliable electrical system for robot factory.",
    "concept": "Load requirements",
    "difficulty": "Medium",
    "reward": 200,
    "required": [
      "battery",
      "wire",
      "led",
      "resistor",
      "switch"
    ],
    "target": "led",
    "lesson": "Load requirements. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 22,
    "title": "Choose the Resistor",
    "district": "The Industrial Zone",
    "objective": "Design a reliable electrical system for choose the resistor.",
    "concept": "Resistance selection",
    "difficulty": "Medium",
    "reward": 210,
    "required": [
      "battery",
      "wire",
      "led",
      "resistor",
      "switch"
    ],
    "target": "led",
    "lesson": "Resistance selection. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 23,
    "title": "Voltage Drop",
    "district": "The Industrial Zone",
    "objective": "Design a reliable electrical system for voltage drop.",
    "concept": "Voltage drop",
    "difficulty": "Medium",
    "reward": 220,
    "required": [
      "battery",
      "wire",
      "led",
      "resistor",
      "switch"
    ],
    "target": "switch",
    "lesson": "Voltage drop. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 24,
    "title": "Overload Alert",
    "district": "The Industrial Zone",
    "objective": "Design a reliable electrical system for overload alert.",
    "concept": "Overcurrent",
    "difficulty": "Medium",
    "reward": 230,
    "required": [
      "battery",
      "wire",
      "led",
      "resistor",
      "switch"
    ],
    "target": "led",
    "lesson": "Overcurrent. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 25,
    "title": "The Fuse Saves the Day",
    "district": "The Industrial Zone",
    "objective": "Design a reliable electrical system for the fuse saves the day.",
    "concept": "Circuit protection",
    "difficulty": "Medium",
    "reward": 240,
    "required": [
      "battery",
      "wire",
      "led",
      "resistor",
      "switch"
    ],
    "target": "led",
    "lesson": "Circuit protection. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 26,
    "title": "Power Budget",
    "district": "The Industrial Zone",
    "objective": "Design a reliable electrical system for power budget.",
    "concept": "Electrical power",
    "difficulty": "Medium",
    "reward": 250,
    "required": [
      "battery",
      "wire",
      "led",
      "resistor",
      "switch"
    ],
    "target": "led",
    "lesson": "Electrical power. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 27,
    "title": "Motor Works",
    "district": "The Industrial Zone",
    "objective": "Design a reliable electrical system for motor works.",
    "concept": "Motors",
    "difficulty": "Medium",
    "reward": 260,
    "required": [
      "battery",
      "wire",
      "led",
      "resistor",
      "switch"
    ],
    "target": "repair",
    "lesson": "Motors. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 28,
    "title": "Factory Fault Finder",
    "district": "The Industrial Zone",
    "objective": "Design a reliable electrical system for factory fault finder.",
    "concept": "Fault diagnosis",
    "difficulty": "Medium",
    "reward": 270,
    "required": [
      "battery",
      "wire",
      "led",
      "resistor",
      "switch"
    ],
    "target": "led",
    "lesson": "Fault diagnosis. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 29,
    "title": "Industrial Network",
    "district": "The Industrial Zone",
    "objective": "Design a reliable electrical system for industrial network.",
    "concept": "Power distribution",
    "difficulty": "Medium",
    "reward": 280,
    "required": [
      "battery",
      "wire",
      "led",
      "resistor",
      "switch"
    ],
    "target": "parallel",
    "lesson": "Power distribution. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 30,
    "title": "The Production Line",
    "district": "The Industrial Zone",
    "objective": "Design a reliable electrical system for the production line.",
    "concept": "System reliability",
    "difficulty": "Medium",
    "reward": 290,
    "required": [
      "battery",
      "wire",
      "led",
      "resistor",
      "switch"
    ],
    "target": "repair",
    "lesson": "System reliability. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 31,
    "title": "Automatic Drawbridge",
    "district": "Smart City",
    "objective": "Design a reliable electrical system for automatic drawbridge.",
    "concept": "Automation",
    "difficulty": "Advanced",
    "reward": 250,
    "required": [
      "battery",
      "wire",
      "led",
      "resistor",
      "switch",
      "transistor",
      "sensor"
    ],
    "target": "led",
    "lesson": "Automation. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 32,
    "title": "Two-Key Security",
    "district": "Smart City",
    "objective": "Design a reliable electrical system for two-key security.",
    "concept": "AND logic",
    "difficulty": "Advanced",
    "reward": 260,
    "required": [
      "battery",
      "wire",
      "led",
      "resistor",
      "switch",
      "transistor",
      "sensor"
    ],
    "target": "led",
    "lesson": "AND logic. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 33,
    "title": "Sensor District",
    "district": "Smart City",
    "objective": "Design a reliable electrical system for sensor district.",
    "concept": "Sensors",
    "difficulty": "Advanced",
    "reward": 270,
    "required": [
      "battery",
      "wire",
      "led",
      "resistor",
      "switch",
      "transistor",
      "sensor"
    ],
    "target": "switch",
    "lesson": "Sensors. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 34,
    "title": "The Smart Traffic Grid",
    "district": "Smart City",
    "objective": "Design a reliable electrical system for the smart traffic grid.",
    "concept": "Control systems",
    "difficulty": "Advanced",
    "reward": 280,
    "required": [
      "battery",
      "wire",
      "led",
      "resistor",
      "switch",
      "transistor",
      "sensor"
    ],
    "target": "led",
    "lesson": "Control systems. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 35,
    "title": "Logic Inverter",
    "district": "Smart City",
    "objective": "Design a reliable electrical system for logic inverter.",
    "concept": "NOT logic",
    "difficulty": "Advanced",
    "reward": 290,
    "required": [
      "battery",
      "wire",
      "led",
      "resistor",
      "switch",
      "transistor",
      "sensor"
    ],
    "target": "led",
    "lesson": "NOT logic. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 36,
    "title": "Control Tower",
    "district": "Smart City",
    "objective": "Design a reliable electrical system for control tower.",
    "concept": "Transistor switching",
    "difficulty": "Advanced",
    "reward": 300,
    "required": [
      "battery",
      "wire",
      "led",
      "resistor",
      "switch",
      "transistor",
      "sensor"
    ],
    "target": "led",
    "lesson": "Transistor switching. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 37,
    "title": "Automated Elevator",
    "district": "Smart City",
    "objective": "Design a reliable electrical system for automated elevator.",
    "concept": "Actuators",
    "difficulty": "Advanced",
    "reward": 310,
    "required": [
      "battery",
      "wire",
      "led",
      "resistor",
      "switch",
      "transistor",
      "sensor"
    ],
    "target": "repair",
    "lesson": "Actuators. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 38,
    "title": "Security Network",
    "district": "Smart City",
    "objective": "Design a reliable electrical system for security network.",
    "concept": "Digital security",
    "difficulty": "Advanced",
    "reward": 320,
    "required": [
      "battery",
      "wire",
      "led",
      "resistor",
      "switch",
      "transistor",
      "sensor"
    ],
    "target": "led",
    "lesson": "Digital security. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 39,
    "title": "Smart Energy City",
    "district": "Smart City",
    "objective": "Design a reliable electrical system for smart energy city.",
    "concept": "Energy management",
    "difficulty": "Advanced",
    "reward": 330,
    "required": [
      "battery",
      "wire",
      "led",
      "resistor",
      "switch",
      "transistor",
      "sensor"
    ],
    "target": "parallel",
    "lesson": "Energy management. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  },
  {
    "id": 40,
    "title": "The City That Thinks",
    "district": "Smart City",
    "objective": "Design a reliable electrical system for the city that thinks.",
    "concept": "Integrated systems",
    "difficulty": "Advanced",
    "reward": 340,
    "required": [
      "battery",
      "wire",
      "led",
      "resistor",
      "switch",
      "transistor",
      "sensor"
    ],
    "target": "repair",
    "lesson": "Integrated systems. Observe the city metaphor, build the circuit, run the simulation, then compare the result with the electrical blueprint."
  }
];
