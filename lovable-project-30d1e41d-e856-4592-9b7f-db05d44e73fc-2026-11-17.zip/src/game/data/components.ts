import type { ComponentKind } from '../types';
export const COMPONENTS: {kind:ComponentKind;name:string;symbol:string;city:string;description:string;defaultValue?:number;unlock:number}[] = [
 {kind:'battery',name:'Battery',symbol:'▣',city:'Power Station',description:'Supplies a voltage difference to drive charge around a complete circuit.',defaultValue:9,unlock:1},
 {kind:'wire',name:'Copper wire',symbol:'〰',city:'Copper Highway',description:'Connects terminals and provides a low-resistance path.',defaultValue:0.1,unlock:1},
 {kind:'led',name:'LED',symbol:'✦',city:'Light Tower',description:'A diode that emits light when forward biased above its threshold voltage.',defaultValue:2,unlock:1},
 {kind:'resistor',name:'Resistor',symbol:'▱',city:'Tollbooth',description:'Limits current and converts electrical energy into heat.',defaultValue:330,unlock:1},
 {kind:'switch',name:'Switch',symbol:'◉',city:'Drawbridge',description:'Opens or closes a path in the circuit.',unlock:1},
 {kind:'diode',name:'Diode',symbol:'▶',city:'One-way Street',description:'Conducts primarily in one direction.',defaultValue:0.7,unlock:5},
 {kind:'capacitor',name:'Capacitor',symbol:'║',city:'Energy Garage',description:'Stores energy in an electric field. Dynamic simulation is a later module.',defaultValue:1000,unlock:12},
 {kind:'transistor',name:'Transistor',symbol:'⌁',city:'Control Tower',description:'A small input signal controls a larger current path.',unlock:25},
 {kind:'and',name:'AND gate',symbol:'&',city:'Dual-Key Control',description:'Output is ON only when both inputs are ON.',unlock:31},
 {kind:'or',name:'OR gate',symbol:'≥1',city:'Choice Junction',description:'Output is ON when at least one input is ON.',unlock:33},
 {kind:'not',name:'NOT gate',symbol:'¬',city:'Inverter Tower',description:'Reverses a Boolean input.',unlock:35},
 {kind:'motor',name:'Motor',symbol:'⚙',city:'Motion Works',description:'Converts electrical energy into mechanical motion.',unlock:21},
 {kind:'sensor',name:'Sensor',symbol:'⌖',city:'Detection Station',description:'Turns an environmental measurement into a control signal.',unlock:31},
 {kind:'fuse',name:'Fuse',symbol:'⏚',city:'Safety Station',description:'Opens the circuit when simulated current exceeds its rating.',defaultValue:0.05,unlock:21}
];
